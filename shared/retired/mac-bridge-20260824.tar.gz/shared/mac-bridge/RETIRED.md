# mac-bridge 舊信箱已退役 — 2026-08-20

`shared/mac-bridge/to-mac/`、`to-vps/` 與 `archive/` 現在只保留歷史紀錄；
請勿再投遞新訊息。`mailbox-watch.service` 仍維持停止及 disabled，舊目錄沒有
自動消費者。

歷史檔案不得刪除、重送或搬移。2026-08-22 切換時，`to-vps/` 有 61 封；
其中晚間新增的兩封已由 Anya 人工讀取並回報，依老兔裁定不補送。

## 現行雙向路徑

兩個方向使用不同目錄，避免把 Mac 非常駐的 pull 模式混入 VPS 常駐 gateway：

- **Mac → VPS**：Mac 經 SSH 原子寫入
  `/home/oldrabbit/.claude-bots/relay/<message-id>.json`，固定使用
  `from_bot: "mac-agent"`。現行 pod-system relay gateway 會驗證、消費，並把
  成功處理的原檔移入 `relay/read/`；不認得的寄件者仍移入
  `relay/quarantine/`。
- **VPS → Mac**：VPS 寫入
  `/home/oldrabbit/.claude-bots/relay-to-mac/<message-id>.json`。Mac agent 在
  SessionStart 主動取信，成功處理後移到 `relay-to-mac/archive/`。

VPS → Mac 的完整檔名、JSON 欄位、原子寫入、重試與歸檔約定，見
`/home/oldrabbit/.claude-bots/relay-to-mac/README.md`。

Hermes SSH terminal backend 仍是 Mac 頻外維修與同步操作通道；它不取代
非常駐 agent 所需的非同步留言。Mac 以 `oldrabbit` 同 uid SSH 進入 VPS，
本切換不新增或宣稱任何寫入範圍限制。

## 保留與復原

舊腳本與 service unit 因稽核及歷史引用保留，但不要重新啟用
`mailbox-watch.service`。若新 relay 通道故障，先保留失敗檔與 log、修復新路徑；
任何回復舊信箱的決定都必須另行核准。
