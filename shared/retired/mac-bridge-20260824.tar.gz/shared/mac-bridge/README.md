# mac-bridge — mac-agent ↔ VPS-bot 檔案信箱

非常駐的 Mac agent 跟 always-on VPS bot 的通訊管道（取代收不到的 Mattermost）。
完整設計：`~/.claude-bots/shared/specs/mac-agent-comms.md`

- `to-mac/`  VPS→mac 的訊息（mac 讀完 `mv` 到 `archive/`）
- `to-vps/`  mac→VPS 的訊息（VPS 讀完 `mv` 到 `archive/`）
- `archive/` 雙向已處理

訊息＝markdown 檔，檔名 `{YYYYMMDD-HHMMSS}-from-{sender}-{slug}.md`，frontmatter(from/to/ts/thread/needs_reply)+正文。
目錄即狀態（在收件夾＝未處理）。只存 VPS、不走 Syncthing。

mac 端起手收件：
`ssh -i ~/.ssh/gcp_channellab oldrabbit@34.80.149.148 'cat ~/.claude-bots/shared/mac-bridge/to-mac/*.md 2>/dev/null'`
