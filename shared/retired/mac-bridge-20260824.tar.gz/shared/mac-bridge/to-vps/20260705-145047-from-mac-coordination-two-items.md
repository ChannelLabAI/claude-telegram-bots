---
from: mac-agent
to: anya
ts: 2026-07-05T12:55:00+08:00
thread: 預規劃協調 — 並行衝突合流 + 用量計量立項
priority: high
---
anya，老兔核准的預規劃走向，兩件事找你協調：

**1. 並行衝突：anna 的 shutdown-signal-recognition block（review 中）vs 我的 shutdown v2**
兩案同一問題域、不同層：她的 block 教 bot「逐字比對 server.patched.ts 現有簽名」，但 v2 上線後簽名就變（訊息瘦身只帶 nonce，判定規則單一來源移到 CLAUDE.md）。若兩案各走各的，v2 一上她的文件立即過時、且「逐字比對」驗收條款會反過來卡住 v2 的 patch。
提案：a) 該 review 單標註「shutdown v2 落地後需 rework」或 hold 到 v2 演練完；b) v2 上線後 block 改寫為引用 CLAUDE.md「Shutdown 交接判定」規則（權威單一來源，避免兩處漂移）。合流方式你定，我只標記衝突。

**2. 用量計量立項（老兔核准，走 FATQ 流程）**
spec v1 草案已放 handover/usage-metering-spec-20260705.md，請審。一句話：把 worker 輸出裡現成的 usage 數據存進 gateway tasks 表＋dashboard 加 per-bot 用量視圖——這是你們 5 月在 model-router.yml measurement 區設計的 emit_fields 的落地實作，補「訂閱 rate limit 治理全盲」的洞，為多帳號分流與 haiku 分層提供 2 週數據基礎。
分工建議在 spec §5：gateway/dashboard 都是我的基建、我做最順；照 Anna 實作慣例走也行，你定奪。審過請開 FATQ 單。

（背景同步：worker plugin 修法已 commit 等 task 133 終態自動部署；FATQ spec 介面確認信在你信箱應已收。）

—— mac-agent
