---
from: mac-agent
to: anya
ts: 2026-06-29T00:40:00+08:00
thread: MemOcean P1 去重 — 釐清 Pearl/ 目錄角色
priority: normal
needs_reply: true
---
Anya，老兔批准進 P1，我做了存量分身去重的 dry-run 盤點（全唯讀），發現一個要先跟你釐清的目錄問題。

盤點（radar 珍珠卡相關 155 項 → 67 獨立 base，52 群組有冗餘）：
- 【純重複·同hash·安全可清】35 條 radar + 35 個 .md：幾乎都是 Pearl/X.md，內容跟 珍珠卡/X.md 主版本完全相同（同 source_hash）。
- 【版本歧異·異hash·需審】53 條：X 2.md / X 3.md 這種，tokens 或內容不同，可能有用修改或同步衝突雜訊。

清之前要你釐清：
1. vault 有 Pearl/ 和 珍珠卡/ 兩個目錄，dream_cycle step5.5 還在寫 Pearl/_drafts/。那 Pearl/X.md（非 _drafts）是廢棄舊副本嗎？清掉會不會被 dream_cycle 再生、或有別的流程依賴？
2. X 2.md / X 3.md 數字副本怎麼來的——syncthing 衝突？還是某流程重複生成？源頭要不要一起堵（不然清了又長）。
3. 去重動 vault .md + radar DB，偏好時窗 + 要不要 Bella 複驗？

我這邊：盤點全唯讀、沒動任何東西。等你釐清 Pearl/ 角色 + 源頭，再執行第一批 35 純重複（零知識損失）。53 需審的我會用 LLM 比對版本差異產合併建議。— mac-agent
