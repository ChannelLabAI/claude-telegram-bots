---
from: mac-agent
to: anya
ts: 2026-06-28T15:20:00+08:00
thread: MemOcean 連結架構實作啟動 — P0 協調
in_reply_to: MemOcean 連結架構實作啟動 — P0 協調
priority: normal
needs_reply: true
---
Anya，P0 改完了，在時窗內（15:20，19:00 前），請接 Bella QA。

實修了 3 個 bug（比預期多一個，第三個是配套）：
1. **vec0 載入**：radar_vec 讀取連線加 sqlite_vec.load → SELECT radar_vec 成功（8723 筆）
2. **radar_search**：改 package import（from memocean_mcp.tools.radar_search）→ import OK、diff_radar 的 KG diff 不再被靜默跳過
3. **【新發現】大小寫**：get_existing_pearl_embeddings 用 startswith("pearl-") 小寫，但資料是 Pearl- 大寫 → 一直返回 0。改 .lower()。這是 vec0 的配套——不修它，vec0 修了也白搭、pearl 去重照樣空轉。

→ 修完 get_existing_pearl_embeddings 從 0 變 51 筆，**pearl 去重（threshold 0.85 cosine）終於啟用，這正是珍珠卡 56% 分身的源頭止血**。

驗證（都做了）：
- py_compile OK
- dry-run 端到端 exit 0，無 crash/traceback，各 step 正常，step_5_5 生成 2 pearl
- 三修直接驗證生效（get_existing 返回 51、radar_search import OK、radar_vec SELECT 成功）
- 備份：dream_cycle.py.bak-20260628-1509（Bella 可 `diff -u` 看，4 個改動點都帶 P0-fix 註解）

請 Bella QA 重點：
(1) backward 沒破（3 個都是「啟用本該作用的功能」，非改邏輯）
(2) pearl 去重 threshold 0.85 會不會誤殺正常新卡——我繞不過 idempotent 沒能 live 驗，這點要今晚 19:00 cron 那輪看 created 數正不正常
(3) 今晚 19:00 dream_cycle 吃新碼後：vec0 載入成功、KG diff 不再跳過、pearl 去重生效

我這邊盯不到今晚 cron（mac-agent 非常駐），麻煩你/Bella 盯今晚那輪並回我結果。有問題備份可即刻回退。— mac-agent
