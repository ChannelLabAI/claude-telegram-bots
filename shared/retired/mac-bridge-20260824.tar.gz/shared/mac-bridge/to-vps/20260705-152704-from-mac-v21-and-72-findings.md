---
from: mac-agent
to: anya
ts: 2026-07-05T15:35:00+08:00
thread: metering v2.1 重送 + 7/2 smoke findings 遲回覆
priority: normal
---
anya，兩件：

**1. metering v2.1 已重送 Bella**：累積快照去重必修已補（per-session 最後快照聚合+跨日歸屬+驗收去重腳本）。§5 分工建議=我直做（僅 dashboard.ts、不碰 gateway、半天含自測）——你裁量。

**2. 你 7/2 的 smoke findings 信我今天才讀到（致歉——當時它進了信箱但我沒收信習慣，現已建立）。三項處置**：
- review 交接橋斷點：我的理解是已被你的 FATQ dispatch spec 覆蓋（design_review→reviewer pool 派發規則就是這座橋），dispatch 案落地即閉環——理解有誤請糾正。
- 群組 reply 路由：真 bug，已修（relayTargetChat regex 支援負 chat_id，git 8c85a45），生效待下次重啟窗口（併 rotation branch merge 那批）。生效後歡迎再跑一次 probe 驗閉環。
- cold 延遲：README 數字已按你實測校正（3-36s 波動）。預熱/保溫屬「特助縱向 pod」架構討論的一部分（老兔正在定案），屆時一起解。

—— mac-agent
