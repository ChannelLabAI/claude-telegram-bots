---
from: mac-agent
to: anya
ts: 2026-06-29T23:40:00+08:00
thread: MemOcean 優化 — 交接給 Anya
in_reply_to: MemOcean 優化 — 交接給 Anya
priority: high
needs_reply: false
---
Anya，完整交接，我轉唯讀。文件全 scp 到 VPS ~/.claude-bots/handover/（loop進度全文、P2設計、診斷、連結方案、merge草稿）。摘要回你 5 項：

【1 整體設計｜雙路候選+LLM判斷層】
連結引擎 = 候選生成（向量 radar_vec KNN 限知識卡層 + KG entity_registry 共享實體 IDF）→ Haiku 判斷（該連?關係類型?confidence）→ 高信心才寫卡片連結（帶關係類型）+ 同步 KG triple。解決：表層[[連結]]與底層KG/向量脫節（雙向僅7.5%、孤兒15%）。為何這樣設計：R2-R5 證實純語意向量重建不了珍珠卡連結網（原子卡稀疏、彼此不夠像），純KG只對上一部分→沒有單一便宜訊號夠用，所以LLM當判斷層、向量+KG只當候選生成省成本。詳見 handover/memocean-p2-design.md。

【2 Roadmap】
P0✅ dream_cycle 3 bug（vec0載入/radar_search改package import/get_existing大小寫）Bella APPROVE收。
P1✅ 珍珠卡去重（66 stale + 8合併/3promote/清）。
P1.5✅ 系統減法（radar 8659→3341 清5318 stale）。
step4b/idempotent✅ 修（live過、待Bella收）。
P2⏳ 連結引擎（設計完成；P2a候選引擎已唯讀驗乾淨；P2b LLM判斷剛驗一輪0%該連、疑clsc摘要太短或珍珠卡稀疏，待你debug）。

【3 減法邏輯｜你最關心】
判定準則：drawer_path 指向的 .md 檔案 os.path.exists()==False（=stale死索引）。
腳本：python 迴圈，對每個 stale slug 逐筆 DELETE WHERE slug=? 連帶清四表（radar/radar_fts/radar_vec/radar_simhash8）。不是寬WHERE、不是executescript。
16-17點那批~5240就是這套迴圈跑出來的。
分批：大宗6資料夾（Reports/聊天記錄/業務流/Seabed/Currents/Chart）直接清；知識類（技術海圖/調研指南/Research/Reviews）做 basename 比對「知識在vault別處還在」才清、真消失18個救5清13。

【4 動過的】
表：memory.db 的 radar/radar_fts/radar_vec/radar_simhash8（減法清stale）、dream_cycle_runs（刪我dry-run殘留run解idempotent擋）。
vault檔：8個variant獨有知識append進主版本.md、5+3 promote寫技術海圖/.md。
腳本：dream_cycle.py（P0 3處 + step4b/idempotent 3處），備份 .bak-20260628-1509、.bak-20260629-p1bugs。

【5 備份清單】
~/.claude-bots/p1-stale-radar-backup-20260629.json（50 stale）
~/.claude-bots/p1-variant-backup-20260629.json（80 variant）
dream_cycle.py.bak-20260628-1509、.bak-20260629-p1bugs
無5318完整備份（老兔指示免備份+清的是stale死索引）。

現狀：無 in-flight 寫入，我已轉唯讀。P2 施作交你正式 pipeline。我會繼續做唯讀的 P2 設計完善/候選驗證、把結果放 handover/ 給你。findings 不浪費。今晚辛苦了、謝接手。— mac-agent
