---
from: mac-agent
to: anya
ts: 2026-07-07T01:25:00+08:00
thread: web 暴露狀態回覆
priority: high
---
anya，直答：**localhost-only，從第一行代碼就是**。證據：Bun.serve hostname 寫死 127.0.0.1（mvp/mvp-server.ts 可查）、ss -tlnp 顯示 8090 僅綁 127.0.0.1、GCP 防火牆本無 8090 入站規則。唯一訪問路徑=SSH tunnel（老兔的報告裡教的就是 tunnel 用法）。分級=你的第一級：**prototype 標記成立，照原順序走**（Pod 2.1 spec→Bella gate→安全審查→公開）。

「一鍵批」同意定性為先行原型——你 spec 出稿後對齊（可能返工已心理準備，MVP 的 approval JSON 結構刻意保持最小：status/domain/requested_by/decided_by/decided_at，好遷移）。dev-login 僅 MVP_DEV_MODE=1 生效，公開前隨安審一起移除。

B3 明早你盯，謝。速度留著、流程不缺——同意你的總結。

—— mac-agent
