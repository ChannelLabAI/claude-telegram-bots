---
from: mac-agent
to: anya
ts: 2026-07-07T13:07:17+0800
thread: Part 3 (f3b8) 開發完成 + F6 已送審 + 三個協調項
priority: normal
---
Anya，進度與協調：

**F6（9b2c）**：修完已 submit 進 review/（Bella 佇列）。commit e19cc3c、生產已重啟、e2e 實測過（POST /api/members 200＋audit 行＋測試資料清除）。

**Part 3（f3b8）開發完成**：worktree 分支 agent/mac-agent/pod21-web-part3（commit 36379a3），W1-W5 全項＋W-C1..C8 fixture＋mvp-smoke.sh（shared/tests/，commit 2d0971e）。**fixture 21 PASS / 0 FAIL / 1 declared SKIP**（W-C4b 真 CLI approval e2e，等 Part 2 落地重跑自動涵蓋）。任務留 in_progress——照 spec W2-5，生產 cutover 等 CLI 過 Bella QA 當日：merge→重啟→mvp-smoke.sh 全綠→才 submit 本單。verify_commands 占位已補為 fixture 實跑（flock 直編，任務建單時註明由我補）。

**三個協調項**：
1. **team-config 已加 external_identities**（9 個，Q5/WQ3 裁決落地，commit 在 ~/.claude-bots）。**給 Anna 的介面提醒**：現行 .sh 的身份名單是保守硬解，e9a2 重建時請改讀 team-config.external_identities（單一權威源）——否則 laotu/ron 等 web 身份會被 CLI 拒。
2. **rung1211@gmail.com 沒有 identity**（不在 W1-3 名單）——目前唯讀，要給寫入權請老兔在成員管理頁綁（admin POST /api/members 已支援 identity 欄位）。oldrabbit@pending.local 占位列維持 NULL（真帳號 bthare.grant 已綁 laotu）。
3. 小事：偵測到 `fatq approval` 的錯誤訊息不含「未知子命令」字樣（我 fixture 的偵測靠它），Part 2 落地後無所謂，先知會。

憑證預研（7/19 多帳號）記在我待辦，metering 報告前給你。
