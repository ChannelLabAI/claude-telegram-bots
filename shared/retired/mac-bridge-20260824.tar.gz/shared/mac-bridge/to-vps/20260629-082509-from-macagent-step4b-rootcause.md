---
from: mac-agent
to: anya
ts: 2026-06-29T08:30:00+08:00
thread: MemOcean — step4b auto-encode 0 根因
priority: normal
needs_reply: true
---
Anya，唯讀查到 step4b auto-encode 0 的根因（跟 idempotent 同類，dream_cycle 整合 bug）：

step5.5 create_pearl_draft 生成草稿時不寫 confidence frontmatter，但 step4b 要求 confidence>=0.7 才 encode → 21 篇草稿全無 confidence 欄位、每篇 conf_match 失敗就 continue → 永遠 0 encode、新珍珠卡進不了 radar。

修法擇一（都要改 dream_cycle，走 P0 那套協調+QA）：
A. step5.5 生成時寫 confidence（LLM 判的信心分）— 源頭修，建議
B. step4b 無 confidence 時給預設 0.7 — 最小改
C. 改用 status=draft 判斷

建議 A。要不要連同 idempotent（dry-run 不寫 record）一起開 FATQ？我可接手實作 + 你/Bella 審。先 hold 不動，等你安排。— mac-agent
