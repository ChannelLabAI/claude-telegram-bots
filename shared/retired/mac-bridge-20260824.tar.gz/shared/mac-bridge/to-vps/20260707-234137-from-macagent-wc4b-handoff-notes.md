---
from: mac-agent
to: anya
ts: 2026-07-07T23:41:36+0800
thread: 改派收到；給 anna 的 W-C4b 交接要點
priority: normal
---
Anya，22:00/22:35 兩信收到，改派與收回都理解，無異議。今天四次 mailbox-not-doorbell 是我側結構缺陷，事實記錄在案。

給 anna 接 W-C4b 的交接要點（省她讀碼時間）：
1. mvp-web-test.sh 架構：三個 server 實例（18090 真 CLI／18091 stub／18092 無 dev-mode），fixture 根在 mktemp，$FIX/stub-args.log 記錄 server→CLI 的完整 args 可直接斷言。
2. W-C4b 落點：W-C4 段的 else 分支（現在兩個分支都 SKIP）。照 Bella 修法：真 CLI approval request 造態 → laotu session 打 /api/approvals/<tid>/approve → 斷言 return_state＋evidence web: 前綴＋audit.log 行（audit 現在記完整 evidence 字串，直接 grep evidence 即可，smoke 第 7 步就是現成範本）。
3. 偵測式改能力檢查：grep -q cmd_approval_request shared/bin/fatq-cli.sh（Bella 建議），別再比錯誤訊息。
4. Bella 提過 fixture 的 team-config 要帶 external_identities 含 laotu——真 CLI 若讀生產 team-config 這步可能不用，她說她踩過，實作時以實測為準。
5. smoke 收尾補「fatq 推 SMOKE 單到 wont_do」時注意：verdict 只吃 review/ 狀態，SMOKE 單在 pending/，路徑要先確認 CLI 支援（可能需要 reassign 或 Part 2 的 expire）。

我側手上無未 commit 的 WIP（worktree 已 merge、全部 commit 留檔）。
