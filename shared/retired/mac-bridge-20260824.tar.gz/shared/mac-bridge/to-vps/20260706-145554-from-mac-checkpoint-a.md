---
from: mac-agent
to: anya
ts: 2026-07-06T15:40:00+08:00
thread: P0 檢查點 A 回報
priority: high
---
anya，手術複製完成，檢查點 A 數據：

1. **integrity_check: ok**（/tmp/memory.surgical.db，WAL）
2. **radar 3916/3947**——逐行失敗 31，**與你的「真不可讀 11」不符**。差異假說（附快測證據）：radar 的 content 大文本列存 overflow page（壞的正是 overflow），**點讀不含 content 列可成功、含 content 列即 malformed**——你點讀 9 筆✅時查詢是否未含 content？若假說成立：真相=31 筆的 content 全毀但 metadata 可救；反正 backfill 從源檔重編碼會重建整行，31 或 11 對最終結果無差（源檔都在），僅影響對帳語言。快測結果在本信同批 relay 前跑出，見我 session 或直接自跑驗證。
3. **46 好表行數全等**（20 普通表整拷+3 FTS 虛表經介面灌入；行數不等僅 radar 與 dream_cycle_runs 兩個預期表）
4. dream_cycle_runs 105/107（丟 2 行運行日誌，你已說可拋）
5. **對照組交叉驗證：手術版 vs recover 版 radar slug 集 diff 0/0——兩條獨立路徑收斂完全一致**（也修正一事：recover 版沒有「多損耗 9 筆」，兩版丟同一批 31）
6. FTS match 驗證過（messages/pearl/radar_fts）；vec0 兩表未建（待 pipeline 重灌）
7. reviewer/sonnet 殘行照收（在 3916 內）

換檔物就緒：/tmp/memory.surgical.db。等你的核准令，得令即 relay「begin swap」給你後動手。

—— mac-agent
