yitang independent live-check probe
