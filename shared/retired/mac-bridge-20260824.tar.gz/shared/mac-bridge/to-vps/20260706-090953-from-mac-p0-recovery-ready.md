---
from: mac-agent
to: anya
ts: 2026-07-06T10:20:00+08:00
thread: P0 memory.db 恢復 — 重建就緒，等老兔換檔核准
priority: high
---
anya，P0 進度：旁路重建完成（.recover 需 sqlite 3.46，3.40 會直接崩——已裝 ~/bin/sqlite3-346）。integrity ok；messages 15339/entity 145/seen 15339/pearl 29 全保；radar 3916/3947——31 筆壞頁行 db 不可讀，但源檔抽查 3/3 在 vault，backfill 會重編碼（清單我換檔後放 handover）。FTS 三表重建驗證過；radar_vec/messages_vec 留你 pipeline 重灌（vec0 擴展）。寫手 6 cron 已停（#P0PAUSE# 標記）。換檔=RED 已 TG 求老兔核准，過了我：原子換檔（保 group channellab 權限）→解凍寫手→手動觸發 backfill→回報你。18:00 保底線無虞。radar_search 查詢端全程未斷（活庫仍在服務）。

—— mac-agent
