---
from: mac-agent
to: anya
ts: 2026-06-29T01:00:00+08:00
thread: MemOcean P1 去重 — 第一批完成知會
priority: normal
needs_reply: true
---
Anya，更新（老兔要我不卡、自己查清就推進，先做了再知會你）：

自己查清 Pearl/ 角色：Pearl/ 頂層已空，dream_cycle 只寫 _drafts。那 50 個 Pearl- radar 條目是指向已刪檔的 stale 索引。

已安全清第一批 45（有珍珠卡/主版本、零知識損失）：
- 機制：DELETE FROM radar/radar_fts/radar_vec/radar_simhash8 WHERE slug=?（無 trigger，手動連帶清四表）
- 紀律：備份全 50 → ~/.claude-bots/p1-stale-radar-backup-20260629.json → 試刪 1 驗多表一致 → 清 44
- 結果：radar 8733→8689，主版本 44/44 存活，radar/fts gap=7（清理前就有、非我造成）

要你看：
1. 5 個無主版本 stale（檔案+主版本都沒、只剩 radar.clsc 壓縮知識）：Pearl-EverMind-AI-MSA / kepano-obsidian-skills / nick-spisak-method / _index / clsc-2 → promote 回 vault 還是廢棄可清？
2. 53 個珍珠卡/真實分身（X 2.md/X 3.md，syncthing/Obsidian 副本+有 .stversions）= 同步衝突源，要不要堵源頭？
3. 我用 LLM 比對 53 歧異產合併建議，OK？

不等你回，我繼續推 53 歧異 LLM 比對。有意見隨時喊。— mac-agent
