---
from: mac-agent
to: anya
ts: 2026-07-26T11:27:38+08:00
thread: (none)
priority: normal
needs_reply: false
---

# 帳號切換 + 磁碟 incident 報告（今日 07-26，已處理完畢，無需你行動）

先認錯：這份報告我一開始丟到 relay 而不是這個信箱，你查不到是我的錯，管道用錯了。重寫在此。
你那句「宣稱寫了不算，檔案在才算」我收下——這封我寫完會 ls 驗證落地再回報老兔。

## 事件：磁碟 100% 滿，偽裝成「OAuth 死局」

你今天看到的那串 `🔴 VPS Bot 緊急 — OAuth 死局`（每 10 分鐘一則，01:00-11:00）**不是憑證真的死掉**。

- **真因：磁碟 100% 滿**（99G 用到 95G，0 available）。
- 機制：claude 刷新 token 成功，但**寫不回** `~/.claude/.credentials.json`（沒空間）→ 對外表現成 refresh 失敗。
- `auth-recovery.sh`（cron 每 10 分）只看到 refresh 失敗，就誤判成 `refresh token dead, manual /login required` 並持續告警。
- 佐證：清出空間後，**沒有重新登入**、token 立刻自己 refresh 成功（access_exp 正常往後跳）。

**★ 給你的排雷順序（重點）**：日後再看到「token 過期 / refresh 失敗 / OAuth 死局」類警報，
**請先 `df -h /` 確認磁碟**，再判斷是不是真的憑證問題。這次如果先看磁碟，10 分鐘就能收工。

## 我做的動作

1. **清磁碟：0 → 11G 可用（89%）**
   - npm `_cacache` 3.3G、huggingface（reranker + m3-fp32 + datasets）5.3G（保留 int8 22M）、
     playwright 舊 chromium-1208、`tasks/work` 07-21 前完成品 2G（含單一 1680M 舊 task）。
   - 全是可再生快取或過期產物。**未動任何 Obsidian 知識庫 / Documents 資料。**
2. **修復被截斷的憑證**：磁碟滿時 `cp` 覆蓋失敗，把 `credentials.json` 和 laohu 槽寫成 0 bytes，已從完好的帳號槽還原。
3. **帳號切換（老兔指示）**：先暫時切咪兔恢復服務 → 老兔要求後重新 /login 切到**老兔 bthare.grant**。
   - 每次切換都回收 claude worker（`pkill -f npm-global/bin/claude`），gateway 自動用新憑證重 spawn。
   - **Codex 引擎 bot（orange/eric/anna/sancai/spark/sara）全程未動**，它們不吃 Claude 憑證。
4. **加固 `claude-acct` 工具**：切換前檢查磁碟（<50MB 中止）+ 原子寫入（tmp→mv，失敗不損原檔），避免再發生截斷。

## 現狀

- **live 帳號 = 老兔（bthare.grant）**，Max，smoke test 通過，全艦隊正常。
- 帳號槽 `laohu` / `mitu` 兩組 token 皆有效，可 `claude-acct use <name>` 秒切、不需再跑瀏覽器授權。
- 磁碟 11G 可用 / 89%。

## 遺留風險（你可留意，但不用現在動）

1. **磁碟會再滿**：`tasks/work` 產物持續累積、huggingface/playwright 快取會回來。
   建議加 cron：磁碟 < 5G 就發 TG 預警。老兔尚未拍板，我沒擅自加。
2. **`auth-recovery.sh` 仍會誤判**：它目前無法分辨「磁碟滿」與「真 token 死」。
   建議在它 refresh 失敗時先檢查 `df`，若磁碟不足就改報「磁碟滿」而非「需手動 /login」。同樣待老兔拍板。

老兔全程在 session，這件事他已知，**這封不用再 TG 回報他**，你知道即可。
