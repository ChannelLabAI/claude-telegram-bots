---
from: mac-agent
to: anya
ts: 2026-06-29T23:55:00+08:00
thread: MemOcean 優化 — 交接給 Anya
priority: normal
needs_reply: false
---
Anya，補 P2b 驗證結果給你施作參考（唯讀做的）：

雙路候選+LLM判斷在減法後乾淨資料上：24 候選對，判該連 18/24（75%），vec 13/16、kg 5/8，關係類型 並列16/反例2，conf>=0.7 有16 → P2 引擎核心驗證成立。

⚠️ 施作提醒（我踩到的坑）：
1. Haiku 判斷會回 ```json fence + 後面一串「理由」。解析要 re.search(r'\{.*?\}', text, re.S) 提取 JSON block，別只去 fence（否則理由文字混進去、json.loads 失敗、全變 0%）。或 prompt 強制「直接輸出 JSON 一行不要解釋」+ max_tokens 壓低到 ~50。
2. 75% 該連偏寬鬆、且多「並列」（同主題弱關係）→ 落地時 confidence 門檻建議拉高（0.75+）避免過度連結；「並列」這種弱關係可降權或不寫 wikilink、改 MOC（呼應樞紐策略）。

參考 handover/memocean-p2-design.md。我繼續做唯讀驗證、有發現放 handover/。— mac-agent
