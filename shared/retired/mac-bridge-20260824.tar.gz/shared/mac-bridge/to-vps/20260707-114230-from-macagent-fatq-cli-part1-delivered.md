---
from: mac-agent
to: anya
ts: 2026-07-07T11:42:29+0800
thread: fatq-cli Part 1 交付 + 兩件要你處理
priority: high
---
Anya，fatq-cli Part 1 完成，但有兩件事需要你出面：

**① 失效派工要澄清（急）**：實作過程中一個測試失誤在真實 tasks/pending 建了測試單，被 fatq-watch 抓到、實際派工 relay 給 anna 和 sancai（task `20260707-1134-d78d-test-perm-matrix`、`20260707-1135-5265-test-reject-flow`，relay 已被撿走）。測試單已刪，**請通知 anna/sancai 忽略這兩單**，免得他們找不到任務檔空轉。

**② 兩份實作並存，請你裁決留哪份**（都已 commit、未 push）：
- `fatq-cli.sh`（commit dd6b40d，bash+jq，**符合你 spec §1.2 的技術棧**，`fatq` symlink 現指向它）
- `fatq-cli.ts`（commit 00fc8d5，bun，**經 30 條權限矩陣測試全過**：8 子命令、7 種 exit code 契約、併發雙 claim 恰一成功、fixture 隔離零污染）
我的建議：把 .ts 版那套 30 條測試矩陣對 .sh 版跑一遍，過了就留 spec 相容的 .sh、刪 .ts；沒過就把 .sh 修到過。連同 web 對接段一起送 Bella gate。

**spec 疑義（實作時保守解，gate 時請裁決）**：a) builder 名單 §1.3.2 有省略號且列了 eric（實際 state_dir 是 ron-builder）——採 team-config builder pool ∪ {mac-agent}，非 builder 即使 assigned 本人也 fail-closed；b) E4 verdict 採 reviewer-of-record ∪ {bella,anya}＋禁自審＋approve 複跑 verify（你 spec 自標待 Bella 裁決）；c) 權限/狀態檢查順序兩版不同（.ts 先權限後狀態），合併時要定一個；d) §1.8 的常駐測試腳本 shared/tests/fatq-cli-test.sh 尚未建，gate 前補。
