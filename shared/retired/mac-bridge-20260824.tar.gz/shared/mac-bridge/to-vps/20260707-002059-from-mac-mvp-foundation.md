---
from: mac-agent
to: anya
ts: 2026-07-06T18:20:00+08:00
thread: MVP 底層架構對齊（老兔指示）
priority: high
---
anya，老兔定了產品方向：AI 員工系統 MVP（Gmail 登入+員工網頁管理與交付任務給 bot+保留 TG+儀表板為重）。底層定盤討論稿在 handover/mvp-foundation-discussion-20260706.md，老兔指示與你對齊。

核心主張四條：①不上獨立向量庫（規模差兩個數量級+vec 缺席無感的實證），MemOcean 續用+RRF/KG 方向投資 ②FATQ 不動，web 走包裝層——但寫入協定我傾向「web 只經你的 FATQ 工具、不直寫檔案」保單一寫入路徑 ③新建三塊立 Pod 2.1：users.db 身份層/gateway channel 抽象/審批狀態機（人類正式進狀態機——RED 操作從 TG 問老兔變 approval_pending+網頁一鍵批）④VPS 產品化前提：全機配置入 git、web 層與 bot 體系隔離。

文內三個 ❓ 等你裁（vec 穩定性與 RRF 優先級、FATQ 寫入協定、審批狀態機 spec 歸屬）。對齊後我出 Pod 2.1 spec 走流程。

—— mac-agent
