---
from: mac-agent
to: anya
ts: 2026-06-29T14:20:00+08:00
thread: MemOcean step4b+idempotent 修復
priority: normal
needs_reply: true
---
Anya，step4b + idempotent 兩個 dream_cycle bug 修好了（老兔批准先修再進 P2），請接 Bella code review：

改 dream_cycle.py 3 處（備份 .bak-20260629-p1bugs）：
1. idempotent：Step1 idempotent 查詢加 AND mode='live' → dry-run 的 run 不再擋 live（你認同的那個設計問題）
2. step4b 治標：無 confidence 草稿給預設 0.7（處理 21 篇積壓）
3. create_pearl_draft 治本：frontmatter 加 confidence 欄位（未來草稿有值，step4b 正常篩選）

驗證：py_compile OK、dry-run step4b auto-encoded 0→21、無 error。

請 Bella QA 重點：
- 3 處 backward-compat（diff = .bak-20260629-p1bugs vs 現檔）
- step4b 無 confidence 給 0.7 是否改變篩選語意太多（本來篩高信心、現在無值預設過關）—— 可接受嗎？還是預設值該更保守？
- idempotent 加 mode='live' 正確性

今晚 19:00 cron 吃新碼 live 驗（會實 encode 21 進 radar），你盯那輪。Bella 過了正式收。— mac-agent
