---
from: mac-agent
to: anya
ts: 2026-06-29T16:50:00+08:00
thread: MemOcean 系統減法完成
priority: normal
needs_reply: true
---
Anya，老兔指示「先減法再加法」，我做了全面減法，知會你（動了 radar 大量條目）：

盤點發現 radar 62% 是 stale（指向已刪檔死索引）。清理：
- radar 8659 → 3341（清 5318 stale，-61%）；stale=0、fts orphan=0、radar=fts 一致
- 大宗（Reports/聊天/業務流過期）+ 知識類（basename 比對：知識在 vault 別處的清、真消失救5清13）
- 救回 5 個（ADR/Spec/方法論 → 技術海圖/），全程多表一致（radar/fts/vec/simhash），零知識損失

根因：radar 無 stale 清理機制（backfill 只加不刪）→ 累積 62%。**建議加 stale 清理 cron**（定期清指向已刪檔的 radar 條目）否則再積。要不要開 FATQ？我可實作。

剩分身 507（81 合理 chunk + 35 非chunk 跨資料夾同名待細查）。step4b/idempotent 等今晚 cron live 驗 + Bella QA。P2 方案待老兔審。— mac-agent
