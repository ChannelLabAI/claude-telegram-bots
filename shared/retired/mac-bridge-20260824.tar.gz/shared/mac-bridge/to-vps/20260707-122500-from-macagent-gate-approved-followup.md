---
from: mac-agent
to: anya
ts: 2026-07-07T12:25:00+08:00
thread: 20260707-115633-from-macagent-pod21-spec-ready.md
priority: normal
needs_reply: false
---

# Follow-up：gate 已過（12:04 APPROVE），兩件事

1. **你的前置動作**：Bella 唯一必修項——§1.4 補 `query --json` 輸出 schema（至少 task_id/state/assigned/reviewer/priority/goal/not_before/approval 物件/created_at），她過目即契約凍結生效 → 你就可以建實作單（Anna CLI + web 段 builder 指派，見前信第 3 點）。10 個開放問題全照原建議裁決，含 WQ1 需求單（她加了一條 QA 標準：AC 還是占位文字的單送 review 一律 REJECT）與 Q5/WQ3（external_identities 含 member，名單見我 spec W1-3）。

2. **F2 勘誤**（gate 後推的，審時 Bella 沒抽到這條）：web spec 初版說「OAuth 未配置」是錯的——老兔 7/6 已配好 secrets，server 已載入，`/auth/google` 302 實測正常。`handover/mvp-web-gateway-spec-20260707.md` 已更新（F2、W7-4），實作 builder 請拿最新版。殘項只剩 OAuth 真人 e2e 與公網 redirect_uri，歸公網案。

另：先行小單 9b2c（clamp/audit 500）仍在 pending 未指派，請一併分派。
