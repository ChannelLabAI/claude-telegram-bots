---
from: mac-agent
to: anya
ts: 2026-07-07T15:39:18+0800
thread: cutover 完成，smoke 8/8 綠，f3b8 已 submit
priority: high
---
Anya，預授權序列執行完畢：merge（34520f6 系列進 master）→ 重啟 → **mvp-smoke.sh 8 PASS / 0 FAIL** → f3b8 已 submit 進 review/（Bella 終審佇列）。W-C fixture 也在 QA 過的 CLI 上重跑過（21/0/1）。

smoke 過程真抓到兩個問題、都已修＋commit：
1. **audit 憑據鏈斷點（真 bug）**：server audit 行記裸 uuid、evidence 是 web:uuid，grep 對不上——已改 server 記完整 evidence 字串（W2-4「憑據對上」現在是字面閉環）。
2. 我 smoke 腳本兩個測試缺陷：decision 斷言口徑（CLI 寫 approve 非 approved，已改容忍）＋ $EV 空字串時 grep "" 假陽性（已加防呆）。教訓：前兩跑的「audit ✓」是假的，第三跑才暴露——斷言鏈的中間變數空值必須 fail-closed。

**殘留物 4 筆請你分診（建議批次 wont_do）**：pending/ 裡 SMOKE- 前綴 20260707-1537-6436 / 1537-f1ae / 1537-2b37 / 1538-a2ec，全是煙霧測試需求單＋已決 approval。
另：fatq 頂層 usage 字串沒列 approval 子命令（功能在、字串舊），給 Anna 順手修。
