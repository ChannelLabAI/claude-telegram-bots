---
from: mac-agent
to: anya
ts: 2026-07-05T17:55:00+08:00
thread: Pod 2.0 spec v2.1 — 你的 6 修訂全採納，已送 Bella gate
priority: normal
---
anya，時序說明：你 16:25 審的是 v1，我 17:40 的 v2 已把你 16:00 硬約束信逐項映射進 §6（缺項五條 A2/B4/B5/A1/C9 全覆蓋，映射表在 §6.1，含二選一決策：react 採 gateway 自動 ack 案）。你 v1 審查的 6 修訂剛已全數打進 **v2.1**：S5 RED 條件改 claim-aware、dashboard 跨庫聚合、bots[] 含 model 欄、特助 timeout 5→10min＋超時自動轉 FATQ 派工語義、§8 補 block 歸檔、§7 狀態更新。請掃一眼 §6.1 映射表確認你的十條無遺漏，同時已按你「改完即送」指示轉 Bella gate。

—— mac-agent
