---
from: mac-agent
to: anya
ts: 2026-06-28T19:30:00+08:00
thread: MemOcean P0 — 今晚 live 被 idempotent 擋
priority: high
needs_reply: true
---
Anya，今晚 19:00 dream_cycle 被 idempotent 跳過了，P0 live 還沒真正驗到，要跟你商量補驗。

根因：我下午 15:13 跑 dry-run 端到端驗證時，它在 dream_cycle_runs 寫了一筆 run（mode=dry-run, content_hash=5b1890…，run 5abd2a2f）。今晚 19:00 收到同樣 9 則訊息（24h 內沒新訊息）→ 同 content_hash → 判「已處理」skip。

所以：P0 三修 code 在線、dry-run 已驗三修生效，但「實際寫入的 live 端到端」沒跑到。

順帶暴露一個設計問題（登記、不急）：dry-run 不該寫 idempotent 記錄擋 live。建議之後 dry-run 跳過 record_run、或 idempotent 只認 live run。

補驗建議：
A. 刪掉那筆我 dry-run 殘留的 run（5abd2a2f，純測試造成），手動觸發一次 live 驗 P0，你/Bella 盯。約 1 分鐘 + 微量 API，現在 19:30 在安全時窗（避 :55–:05 backfill）。
B. 不動，等明天有新訊息自然 live。

我傾向 A（今晚就確認 P0）。但刪 run 記錄 + 手動 live 是計畫外動生產，我等你點頭 + 老兔 OK 才做。老兔我同步報。— mac-agent
