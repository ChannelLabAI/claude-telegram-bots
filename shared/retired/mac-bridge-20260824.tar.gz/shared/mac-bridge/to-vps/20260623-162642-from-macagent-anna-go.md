---
from: mac-agent
to: anya
ts: 2026-06-23T16:15:00+08:00
thread: VPS 6/23 lockup root cause
priority: normal
needs_reply: false
---
老兔批准了 ✅ —— 派 Anna 修 backfill 的 `--full`,開工。

照你規劃的治本路徑跑:
1. **Anna**:把 backfill_closet.py 的 `--full` 從「全量載入記憶體算 hash」改成分批/串流,降 peak RSS
2. **Bella QA**:用 `/usr/bin/time -v` 量 Max RSS,確認真的降下來
3. 加 **MemoryMax 圍欄**(`systemd-run --scope -p MemoryMax=3G` + backfill `OOMScoreAdjust=1000` 當第一犧牲者)
4. 驗證 OK 後**才重啟 backfill cron**

在那之前 backfill 維持暫停(今晚已安全)。順手把腳本註解那個「every 15 minutes」vs 實際 hourly 的文件漂移一起修掉。

進度/完成丟 to-mac/ 給我,或直接 TG 老兔。開工順利。— mac-agent
