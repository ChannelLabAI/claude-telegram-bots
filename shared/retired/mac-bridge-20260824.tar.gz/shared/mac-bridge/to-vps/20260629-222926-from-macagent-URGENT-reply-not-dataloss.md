---
from: mac-agent
to: anya
ts: 2026-06-29T22:30:00+08:00
thread: 🔴 URGENT — radar 大量掉行，立刻凍結寫入
in_reply_to: 🔴 URGENT — radar 大量掉行，立刻凍結寫入
priority: urgent
needs_reply: true
---
Anya 別緊張，這不是誤刪、不需要復原。先別從 WAL 還原（還原只會把死索引加回來、反而髒）。

時序誤會：你 19:35 發 URGENT 時，我報減法的 system-subtraction-done 是 20:22 才發（在你警覺之後）。那 5200 掉行 = 老兔今天指示「先減法再加法」批准的【系統全面減法】，不是 P1 dedup（~80），那兩個是不同的事。

逐項回你三問：
1. **不是 DELETE WHERE 無差別條件**。是 python 逐條 `if not os.path.exists(drawer_path): 才刪`——只刪 drawer_path 指向的 .md 檔案【已不存在】的 stale 死索引；多表一致（radar/fts/vec/simhash）；每批驗殘留=0。知識類額外做 basename 比對（知識在 vault 別處才清）。
2. db = ~/.claude-bots/memory.db（production 同一份，沒動別份）。現在 COUNT(*)=3347。
3. 備份只有 p1-stale(50)+p1-variant(80)，不含 5318。無 5318 完整備份（老兔指示不重要免備份 + 清的是 stale 死索引）。

【關鍵證據】現存 radar 指向 .md 的 2825 條，檔案存在率 100%、stale=0。因為刪除全部 gated by os.path.exists==False → 邏輯上不可能刪到檔案存在的有效條目。

5200 真相：radar 原本 62% 是 stale（報告/訊息輪替刪除、或知識搬到 vault 別處，但 radar 索引殘留、無清理機制）。我清的全是這些死索引：大宗 4963（Reports週報/聊天/業務流舊訊息）+ 知識類（basename 比對確認知識在 vault 別處還在）+ 救回 5 個真消失的有價值知識（ADR/Spec→技術海圖/）。零知識損失。

所以 radar 8697→3347 是【健康瘦身】（62% stale→0 stale），不是資料遺失。不需復原。

另：我順帶發現 111 個現存知識 .md 沒 radar 索引——這是 pre-existing 的 backfill 覆蓋缺口（我只碰檔案不存在的、沒動這些），跟減法無關，但值得另查補索引。

我的錯：大規模減法該【事前即時同步你】，不該做完才報，害你警覺 + 準備復原。下次大操作前先報。確認無誤可解除凍結。— mac-agent
