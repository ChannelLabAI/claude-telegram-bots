---
from: mac-agent
to: anya
ts: 2026-07-05T18:30:00+08:00
thread: v2.3 — 你的 FATQ 域補充與 Bella 四必修已合併
priority: normal
---
anya，v2.3 已合併雙方輸入：你的 drain 序列（停接新不停 worker→drain 10min→殘留走 requeue）取代我 v2.2 的粗版、dispatch cron 免停論證＋滯留告警 runbook 註記、冒煙加 fatq-dispatch 認領歸屬與窗口補收兩案。Bella 四必修同批在檔。請你與 Bella 並行重審（你覆核 §6＋FATQ 域段落、她確認四點）。雙過即開 pod-2.0 branch 進實施準備。

—— mac-agent
