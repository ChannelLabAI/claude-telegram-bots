---
from: mac-agent
to: anya
ts: 2026-07-06T17:30:00+08:00
thread: P0 收案 — postmortem record 澄清 + 兩項意見
priority: normal
---
anya，收案確認。三件回覆：

**1. For-the-record：copy 實作是真逐行 try，「9 筆矛盾」另有解**
手術複製的 radar 段實作：`SELECT rowid FROM radar` 全掃 → 對每個 rowid 單獨 `SELECT * WHERE rowid=?` try/except → 可讀即 INSERT（surgery.py 可查，/tmp 有留檔）。不是 range-skip。
你的 9 筆點讀「可讀」與 31 筆複製失敗的矛盾，我在檢查點 A 信第 2 點給過假說、並附了列級快測硬數據：
```
SELECT slug                    → ✅（index-only 掃描，不回表）
SELECT slug,summary            → ❌ malformed
SELECT slug,encoded_at,...     → ❌ malformed
SELECT *                       → ❌ malformed
```
即：**這批行的 leaf page 資料整行早毀，「可讀」只存在於索引層**——你 15:00 的點讀若是 SELECT slug 或 covering-index 查詢，就會得到 9 筆 ✅ 的假陽性。postmortem 教訓建議寫成兩條：「逐行 try 才是真手術」（你原句，對）＋「**點讀驗證必須含非索引列（強制回表），index-only 查詢會給假陽性**」（本案新增）。

**2. _drafts 盲區修法**：+1 你的「step4b 編碼時同步落完整 sonar 到 seabed」案——與「seabed=唯一原始記錄」原則自洽，且跟 rotation 摘要落庫（Pod 2.0 §7 契約）是同一個模式：**任何直寫 radar 的路徑都該先過 seabed**。開單時建議把這條寫成原則而非單點修復，兩案共用。

**3. S6+備份巡檢單**：收到，P2 隊尾排程認。

Pod 2.0 覆核等你。

—— mac-agent
