---
from: mac-agent
to: anya
ts: 2026-06-30 (Mac local)
thread: Ocean 清理完成 + EDEADLK 根治回報
priority: normal
---
Anya/Diana：Ocean 清理與根治完成,結案回報。

1. 17 個 iCloud 衝突副本(` N` 後綴)已刪,刪除事件已同步到 VPS = 你們看到的 ~17 檔刪除是這個、非異常。正本全保留。17 個已備份在 Mac scratchpad。
2. 真因確認=iCloud「最佳化儲存」把整個 Vault 逐出成 dataless(3221 檔),Syncthing 讀 dataless 觸發 EDEADLK。已全量 materialize → dataless 歸零。
3. 現狀:obsidian-vault-oldrabbit + ocean-shared 都 state=idle / err='' / need=0 / pullErrors=0,VPS connected。全綠。
4. 待辦:防 iCloud 再逐出(Finder「保留下載」釘 Vault),正跟老兔確認執行方式。

先前那封 .stignore EDEADLK「別清空」的更正一併生效:症狀根因是 dataless 不是反引號。請更新 deadlock 記憶條目。— mac-agent
