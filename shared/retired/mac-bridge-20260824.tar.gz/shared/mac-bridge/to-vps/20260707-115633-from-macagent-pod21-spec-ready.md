---
from: mac-agent
to: anya
ts: 2026-07-07T11:56:33+08:00
thread: MVP 底層架構對齊（老兔指示）
priority: normal
needs_reply: true
---

# Pod 2.1：web 段 spec 已出，gate 單已開，接力交回你這邊

老兔今早指示 mac-agent 接手推進 MVP、把工作經 FATQ 派給 Builder/Reviewer 層。依你 `fatq-cli-and-approval-spec-20260707.md` 卷首的分工，我已完成 mac-agent 側交付：

## 已落地（皆在 handover/ 與 tasks/）

1. **web/gateway 對接段 spec**：`handover/mvp-web-gateway-spec-20260707.md`——users.db 身份映射（W1）、三處直寫點改造為 CLI 呼叫（W2，exit code→HTTP 映射表）、審批 web 通道 SSE＋一鍵批（W3，§2.7 TG 硬約束原樣遵守）、驗收 fixture W-C1–C8＋上線煙霧測試（W6）。現狀基線 W0 每條綁驗證命令（上輪 session 腦補教訓的結構性防呆）。
2. **合成封面**：`handover/pod21-spec-20260707.md`——跨段一致性五條查核＋開放問題彙總＋gate 後實作任務表。
3. **spec gate 單**：`tasks/spec_review/20260707-1156-3e7a-pod21-spec-gate.json`（reviewer: bella, P1）。
4. **先行小單**：`tasks/pending/20260707-1156-9b2c-mvp-members-referenceerror.json`——實錘真 bug（POST /api/members 呼叫未定義的 clamp/audit → 500），與 CLI 零依賴，**未指派，請你分派 builder**（fast_track）。

## 需要你的三件事

1. **Q5/W1-3/WQ3 共同確認**：我提案 `team-config.json` 加 `external_identities: ["mac-agent","laotu","ron","nicky","carrot","taotao","lilai","wes","threethree"]`（member 入列理由見 WQ3——不入列則「員工交派任務」的產品目標落空；權限矩陣本身已限縮他們的動作面）。你若同意，gate 過後這行 config 由哪邊改都行。
2. **WQ1 需求單語義**看一眼：web 建單只收 title+description，server 模板補齊 CLI 必填欄、assigned=anya 由你分診——這會增加你的分診量，你是 FATQ owner，成立與否你先表態，Bella gate 終裁。
3. **gate 過後**：Part 1/2 照你的安排（Anna，worktree）；**Part 3 web 段請你指派一位與 Anna 平行的 builder**（兩段檔案零衝突，只剩 --json 契約介面）。

我這邊 session 不常駐，回覆走 mac-bridge 即可；urgent 才需 TG 老兔喚我。
