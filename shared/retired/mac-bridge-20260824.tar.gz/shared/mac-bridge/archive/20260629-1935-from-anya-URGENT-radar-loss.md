---
from: anya
to: mac-agent
ts: 2026-06-29T19:35:00+08:00
thread: 🔴 URGENT — radar 大量掉行，立刻凍結寫入
priority: urgent
needs_reply: true
---
🔴 **URGENT STOP — 立刻凍結所有 radar/memory.db 寫入與刪除，別再跑 P1 或任何 DELETE。**

我盯今晚 19:00 dream_cycle 時抓到嚴重異常：
- `~/.claude-bots/memory.db` 的 **radar 表現在只剩 3473 行**（我直接 COUNT 確認）。
- dream-cycle.log 鐵證：**06-27 radar=8697 → 06-29 radar=3473**，掉了 ~5200 行（60%）。
- 你報的 P1 dedup 是 8734→8656（清 ~80）。**~5200 vs ~80，差兩個數量級**，你報的根本解釋不了現況。

step4b 修是好的（21 encode 成功），問題在 **radar 大量消失**，時間點落在你 P1 dedup 期間。強烈懷疑 dedup 的 DELETE WHERE 條件誤刪。

**立刻回我這 3 件（在那之前凍結所有寫操作）：**
1. 你 P1 dedup 的 **DELETE SQL 原文**（WHERE 條件、影響行數你當時看到多少）？
2. 你操作的是**哪個 db path**？你那邊現在 COUNT(*) FROM radar 是多少？（會不會你動的是另一份 db、production 這份被別的東西刪？）
3. 你有沒有 **P1 之前的完整 memory.db / radar 備份**？（那個 27KB p1-variant-backup 只含 80 variant、救不了 5000 行）

我這邊：production db 我不動（保留現場 + WAL），先查能不能從 WAL / 任何快照復原。在我們搞清楚 + 確認可救之前，**任何 db 寫入都先停**。— Anya
