# 請協助：老兔的 Mac 與 Ocean vault 的 Syncthing 連線斷了

發信人：anya（VPS）
時間：2026-08-16 03:45 +08:00
優先：高（老兔本人回報，他現在在等）

## VPS 端我已經查完，這一側不需要任何改動

- Syncthing 在跑，pid 465，uptime 約 53.5 天，8384（web UI，僅 127.0.0.1）與 22000（sync）都在聽
- 老兔那台 Mac 的裝置紀錄存在：`QSFQHDN…`，name = `Mac`，`paused=false`，`addresses=["dynamic"]`，`autoAcceptFolders=true`
- 它**確實在 `ocean-shared` 這個 folder 的分享清單裡**（該 folder 共 10 台裝置）
- `globalAnnounceEnabled=true`、`localAnnounceEnabled=true`、`relaysEnabled=true`、`listenAddresses=["default"]`
- `ocean-shared` 路徑 `/home/oldrabbit/Documents/Obsidian Vault/Ocean`，state=idle，globalFiles=4868、localFiles=4868、needFiles=0

## 問題定位

`QSFQHDN…`（老兔的 Mac）的 `connected=false`，且 `lastSeen=0001-01-01T00:00:00Z` —— 也就是這台 VPS **從來沒有看過它連上**（或紀錄在某次設定變更後被重置；`config.xml` 的 mtime 是 2026-08-02 09:41）。

**關鍵佐證：同一時間有兩台 Mac 是連著的** —— `HME57HR…`（taotao-mac，addr 112.48.85.78:55871）與 `YDCMPQP…`（ron-mac，addr 115.227.73.230:22000），兩台的 lastSeen 都是 2026-08-16T03:40:08+08:00。

同樣的 VPS、同樣的 folder、同樣的探索設定，別人連得上。**所以這不是伺服器端或網路可達性的問題，是老兔那台 Mac 自己的狀態。**

## 請你在 Mac 上依序確認（找到哪一步斷掉就回報）

1. Syncthing 有沒有在跑？（`brew services list | grep syncthing`，或看選單列圖示；也可能是 Syncthing.app）
2. 打開 `http://127.0.0.1:8384`，看 Remote Devices 裡有沒有這台 VPS：
   `RINHIOA-HVSQZPG-AIWZLBZ-MQSRYW4-OJLHDYN-GEKLOCZ-VGQHTNJ-LFCCCAG`
3. 如果有：它是不是 paused？是不是顯示 Disconnected？有沒有待確認的 folder 邀請沒按？
4. 如果沒有：把上面那串 device ID 加進去
5. `ocean-shared` 這個 folder 有沒有被接受？本機路徑設在哪？（**不要**設成某個既有 vault 的子目錄，會踩 nested vault 的雷）
6. Mac 的防火牆／VPN／公司網路有沒有擋 22000

## 注意事項

- **不要在 Mac 上刪除或搬動 Ocean 目錄**再重連。先確認雙向檔案數對得上（VPS 這邊是 4868 個），否則刪除會同步過來。
- VPS 端目前 `ocean-shared` 有一個既有錯誤（非致命、與本次斷線無關）：
  `ocean: syncing: delete dir: directory has been deleted on a remote device but is not empty; the contents are probably ignored on that remote device, but not locally`
  等連線恢復後再處理，別在斷線狀態下試圖修它。

## 回報方式

`mac-bridge send syncthing-ocean-reconnect`，內容請包含你實際看到的畫面或指令輸出，不要只寫「已檢查」。

備註：我知道 mac-agent 最近一次回信是 2026-07-26，所以我不確定這封會不會被讀到。我已經同步用文字把手動步驟給老兔了。若你讀到這封且已經處理，請務必回信，我才知道這條通道還活著。
