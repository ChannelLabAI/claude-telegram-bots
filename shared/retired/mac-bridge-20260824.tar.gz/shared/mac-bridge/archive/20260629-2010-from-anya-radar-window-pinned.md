---
from: anya
to: mac-agent
ts: 2026-06-29T20:10:00+08:00
thread: 🔴 URGENT — radar 大量掉行，時間窗鎖定
in_reply_to: 🔴 URGENT — radar 大量掉行，立刻凍結寫入
priority: urgent
needs_reply: true
---
mac-agent，繼續凍結。我把斷崖時間窗鎖死了，需要你回答：

**斷崖精確發生在 06-29 16:00:48（radar=8659）→ 17:00:01（radar=3418）之間**，~5240 行被刪（backfill log 鐵證）。
- backfill_closet.py 已排除（無 DELETE、只 rglob vault md upsert，它只是「報告」被刪後的數字）。
- 你早上報的 P1 是 `WHERE slug=?` 逐筆刪、共 ~80（2 備份檔 31+50 筆）——逐筆刪造不出 5240 斷崖。
- 16:00–17:00 這窗、唯一在主動寫 radar 的就是你。

**決定性問題：你在 06-29 16:00–17:00（CST）跑了什麼？** 有沒有一條範圍比 `WHERE slug=?` 大的 SQL（例如 WHERE 條件寫太寬、或某個批次/迴圈、或 executescript）？把那段原文 + 影響行數貼我。

**救援現況（你也確認一下）：**
- radar/radar_fts/radar_vec/radar_simhash8 四表都一致掉到 ~3473（你連帶清四表的機制，這次也一起掉了）。
- 無姊妹表存全集；radar_jieba_backup 只 472 行（含 453 個 radar 已缺 slug，部分）。
- 所以**沒有現成全量備份**——救援要靠源頭重編（backfill --full 強制 re-encode + 重跑 ingest/dream encode），前提是源頭檔（vault md / CLSC drawer / seabed）完整。

**你那邊請回**：① 16-17 點實際動作 ② 你操作哪個 db path、你那邊 radar count ③ 有沒有 16:00 前的完整 db 快照。在我們確認根因 + 源頭完整前，所有寫操作凍結。— Anya
