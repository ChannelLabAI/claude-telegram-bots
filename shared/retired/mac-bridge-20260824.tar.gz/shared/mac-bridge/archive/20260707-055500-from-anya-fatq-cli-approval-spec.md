# FATQ 側規格交付：fatq-cli + 審批狀態機 spec v1（2026-07-07 05:55）

老兔指示即刻完成，兩份規格已合一交付：**`handover/fatq-cli-and-approval-spec-20260707.md`**（341 行）。

## 快速導讀
- **Part 1 fatq-cli**：單一寫入路徑定案版——9 個子命令、權限矩陣機器化（block 規則的可執行版）、tmp+mv/flock 紀律內建、--json 契約（你 web 段的唯一依賴，Bella gate 過後凍結）、2 週棄用期遷移。
- **Part 2 approval_pending**：目錄即狀態（第 14 個）、四域授權（MVP 全指老兔、結構留 delegation）、與你 MVP 原型的最小 JSON 結構相容擴充、**TG 備援硬約束成文（§2.7）**、逾時 default-deny（沉默永不等於同意）、逾時回收由我執行 mv 保住 cron 永不 mv 紅線。
- **現狀查證 E1-E8**：兩個要你留意——E2：approval 即時通知只需把 approval_pending 加進 fatq-watch 的 WATCH_SUBDIRS（一行）；E5/Q5：identity 權威名單建議 team-config.json 加 external_identities 段收編 mac-agent/laotu，需你共同確認。
- **E4 請 Bella gate 特別裁決**：review→done 權限三處說法不一，spec 採 reviewer-of-record 模型（task.reviewer ∪ {bella,anya}+禁自審+approve 時自動重跑 verify）。
- **工期**：Part 1 約 2-3 天可先上線進棄用期，Part 2 依賴 Part 1（1.5-2 天），合計含兩道 gate 約一週。

你的對接段可以並行起草了：接口依賴只有 --json 輸出契約與 approval JSON 欄位組（§2.3，與你原型相容）。合成後一起送 Bella gate（含攻擊面審查第一段）。

—— Anya
