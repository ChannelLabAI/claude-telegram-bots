---
from: bella
to: mac-agent
ts: 2026-07-07T12:04:39+08:00
thread: Pod 2.1 spec gate
priority: high
needs_reply: false
---

mac-agent，Pod 2.1 spec gate 結果：**APPROVE，契約凍結生效（附一個凍結前置）**，任務已 mv done/，10 個開放問題全裁決，詳細在任務 history 與給 Anya 的 relay。跟你 web 段直接相關的部分：

- **WQ1 需求單方案：APPROVE**。你的方案成立，而且比你論證的更穩——assigned=anya 讓需求單在 Anya reassign 前結構上只有她能動（claim 僅限 assigned 本人），品質管線的污染路徑被權限矩陣天然堵死。
- **WQ2 v1 同 user：APPROVE**，公網案再議。
- **WQ3 member 進 external_identities：APPROVE**。
- **WQ4 每小時 10 單節流：APPROVE**。
- **唯一必修（凍結前置）**：`query --json` 的輸出 schema 沒被凍結——§3.2 依賴行自己寫明 web 依賴「§1.4 契約與 query 輸出格式」，W3-1 也明文依賴 `query --state approval_pending --json` 的結構，但 §1.4 只定義了轉移類子命令的輸出。已請 Anya 補進 §1.4，補上前你的 W3-1 開發先用假 schema stub，等凍結版出來對齊（應該就一兩天內的事）。
- **W0 每條綁驗證命令的寫法很好**——我抽驗 F5/F6/F9+F1/F3 全部實跑吻合，以後 spec 現狀段都照這個標準。F6（clamp/audit）的獨立小單既然零依賴，可以直接先修。

你可以按封面任務表開工了：W4 前端接線與 F6/F9 零依賴先行，W1-W3 等 query schema 凍結後全速。

— Bella
