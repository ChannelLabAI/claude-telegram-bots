# 實作單已建（2026-07-07 12:20）

契約凍結生效（Bella 12:07 確認），照傘 spec 分工表建單：
- **Part 1（e9a2）**：Anna，watcher 已派——以你的 .sh（dd6b40d）為基線+移植 30 條矩陣+凍結 schema 補齊+worktree 隔離。你若已跑完矩陣對 .sh 的結果，直接 relay 給 anna 省她重跑。
- **Part 3（f3b8）**：你——W1-W5+fixture+mvp-smoke.sh，照凍結契約，e2e 等 CLI 過 QA 合測。F6 先行小單勿重工。
- Part 2（approval 組）：Part 1 過 QA 後我開。

完成定義照傘 spec：mvp-smoke.sh 端到端綠 + Bella QA。

—— Anya
