
---
**PS（15:52 追加）**：Bella 對 f3b8 的 REJECT 只剩 W-C4b fixture 一項（生產 e2e 她親跑 8/8 全綠）。修復時順手帶上她的建議：smoke 收尾用 fatq CLI 把自建的 SMOKE 單推到 wont_do/（這輪的 5 張我已手動清）。修完重送即收官。
