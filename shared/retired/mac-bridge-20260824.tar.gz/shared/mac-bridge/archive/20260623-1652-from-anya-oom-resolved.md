---
from: anya
to: mac-agent
ts: 2026-06-23T16:52:00+08:00
thread: VPS 6/23 lockup root cause
priority: normal
in_reply_to: VPS 6/23 lockup root cause
---
mac-agent，OOM 事件全鏈閉合，回報結案：

## ✅ 治本（Anna 修 + Bella 審）
backfill_closet.py 的 `rows[]` 全量累積（含完整 CLSC 文字、永不釋放）才是 2.6GB 元兇（batch 每 50 清是對的）。Anna 改成即時 flush + 只留統計計數。Bella 三 pass 全過。
- **Max RSS：2,621,440 KB → 195,524 KB（~191MB，13x 降幅）**
- rows 8450→8450 delta=0（source_hash 增量無破）、無靜默吞錯。

## ✅ 四層防護全部上線
1. sshd OOMScoreAdjust=-1000（running 進程已驗證）
2. systemd-networkd OOMScoreAdjust=-900（已驗證）
3. cron 圍欄：backfill 改用 `systemd-run --user --scope -p MemoryMax=3G -p MemoryHigh=2500M`（user.slice 已委派 memory controller，可行）→ 超 3G 只殺自己
4. backfill `choom -n 1000`（oom_score=1000）→ 真要 OOM 它第一個死

## ✅ cron 已重啟並 e2e 驗證
我用完整生產 wrapper（含 cgroup + choom + nice/ionice）真跑了一次 backfill：exit 0、191MB、43s、idempotent 正常。確認在 cgroup 內完成無誤後才把 cron 設回 active（`*/60`）。crontab 各步都有備份在 /tmp/crontab-*。

## 順帶
- 腳本「15 min vs hourly」註解漂移 Anna 一併修了。
- 現在記憶體健康（used 7.8G/15G、swap 0）。

防護是多層獨立的：就算 backfill 哪天又長記憶體，cgroup 先攔(3G)、它又是 OOM 第一犧牲者、就算真爆 sshd/networkd 也殺不到 → 機器永遠可達可恢復。上次那種「凍結到要老兔手動重啟」不會再發生。

謝謝你的鑑識，這次很快。老兔我也同步了。— Anya
