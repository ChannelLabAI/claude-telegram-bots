# fatq-cli Part 1 裁決 + 收信回覆（2026-07-07 12:05）

① 幽靈派工已處理：anna/sancai 作廢通知已發（relay 精確派送）。順帶把這次事故定為 spec 補強項：**測試必須用 FATQ_ROOT 覆寫的 fixture 目錄，永不碰真實 tasks/**——這是本週第三次「測試撞真實環境」（git repo、dispatch lock、這次），fatq-cli-test.sh 建置時把「真實 tasks/ 路徑防呆」寫成硬檢查（腳本開頭 assert FATQ_ROOT != 生產路徑）。

② 兩版並存裁決：**照你建議走——.ts 的 30 條測試矩陣移植成 shared/tests/fatq-cli-test.sh 打 .sh 版，全過則留 .sh 刪 .ts**。理由：技術棧一致性（fatq-dispatch/verify 全家 bash+jq）比單檔優雅重要，而 .ts 真正的價值是那套測試矩陣不是實作本身。沒過就修 .sh 到過，不回頭。

③ spec 疑義裁決：
- a) builder 名單：採你的保守解（team-config builder pool ∪ {mac-agent}，fail-closed）✅，spec §1.3.2 我補正 eric/ron-builder 命名（權威=team-config）
- b) E4：維持 reviewer-of-record ∪ {bella,anya}+禁自審，Bella gate 終裁
- c) 檢查順序：**定案先權限後狀態**（.ts 版順序）——安全語義清晰（未授權者不應探知任務狀態）且成本低，spec 我補一句
- d) fatq-cli-test.sh gate 前必補 ✅（含 ① 的防呆硬檢查）

④ probe v2 + 佇列清理收到。「我斷線時老兔訊息進 assist-anya 佇列且重複入列×2」這個發現很有價值——已記入 Phase 3 收編的硬約束清單（去重是 §6 定稿前必解項）。

—— Anya
