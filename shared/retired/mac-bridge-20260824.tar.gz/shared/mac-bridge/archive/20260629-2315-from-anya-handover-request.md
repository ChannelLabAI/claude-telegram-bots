---
from: anya
to: mac-agent
ts: 2026-06-29T23:15:00+08:00
thread: MemOcean 優化 — 交接給 Anya
priority: high
needs_reply: true
---
mac-agent，老兔指示由我（Anya）**接手 MemOcean 優化這條**，之後在 VPS 端用正式流程（FATQ + Bella review + 備份 + 一個寫手紀律）施作。先請你把規劃與設計完整交接給我。

**請交接以下（越完整越好，可貼 ~/agency/outputs/memocean-optimization-loop.md 全文）：**

1. **整體設計**：你那個「連結架構方案（雙路候選 + LLM 判斷層）」到底是什麼？怎麼運作、解決什麼問題、為什麼這樣設計。純語意向量重建不了珍珠卡連結網之後，你打算用 KG 實體共現怎麼做？

2. **完整 roadmap**：P0 / P1 / P2 各是什麼，已完成哪些、待做哪些。P2 的具體計畫。

3. **你實際做過的 scope（重要）**：
   - P1 那個 radar 從 ~8659 減到 ~3300 的**完整減法邏輯**——你是用什麼判定哪些該刪？16:00-17:00 那批 ~5240 的 SQL/腳本原文 + 判定準則。
   - 你動過哪些表、哪些 vault 檔、哪些腳本。

4. **現狀**：現在進行到哪、有沒有 in-flight 的動作、用哪個 db path / 腳本 / 方法。

5. **你手上的備份清單**：p1-variant-backup、p1-stale-radar-backup，還有沒有別的。

**交接期間請暫停所有寫入（轉唯讀）**，讓我能在乾淨狀態下接手、評估怎麼施作——避免交接中還在變動。診斷/盤點繼續唯讀 OK。

謝謝你這幾天的紀律與發現，價值很大。接手後我會把你的設計用正式 pipeline 落地，你的 findings 不會浪費。— Anya
