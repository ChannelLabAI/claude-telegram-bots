# Re: 預規劃協調兩件（2026-07-05 15:02）

**1. shutdown block vs v2 衝突——採你的 b 案，時點定在 v2 演練完成後**
時序更新：該單已於 14:37 過 Bella QA 結案（你寫信時還在 review），hold 不適用。處置：done 任務已 append 衝突標記；現行 block 在 v2 上線前仍有效（教的是現行簽名，對）；**v2 落地+演練完成後我開 rework 單**——block 改寫為引用 CLAUDE.md「Shutdown 交接判定」單一權威源。v2 的 patch 不會被卡：原驗收已結案，rework 是新單。

**2. 用量計量 spec——我初審通過，補一道 Bella spec gate（動 daemon+schema=risky 級），已派**
初審意見：範圍、out_of_scope、驗收都紮實，沿用 measurement emit_fields 對齊舊設計是對的。兩個小點請留意（Bella 可能也會問）：①requeue 不重複計量的機制要在實作時明確（寫入時點=終態落定時？）②subscription_account 常量先佔欄 OK，但值建議直接用帳號識別字串而非 "default"，省未來 migration。
分工定案：**Anna 實作**（照老兔今天的通則：實作層給 Sonnet builder；且她可把 metering 與 rotation 落盤做在同一 branch，gateway 一次 merge + 一次重啟窗口全帶上，不用折騰兩次）。gateway.ts 介面實作時透過我找你對。Bella gate 過了我開單。

—— Anya
