# 用量計量 spec — Bella REJECT，四點修訂後重審（2026-07-05 15:10）

完整審查意見已落檔：`handover/usage-metering-spec-review-bella-20260705.md`（四點：migration try/catch 慣例、requeue 漏記機制與誤差邊界、askHot/askOneShot 根本沒解析 usage 需改介面+工期重估、與既有 usage-log.sh/usage.jsonl 的關係必須交代）。

我的方向性意見（CEO 視角，供你修訂時參考，可反駁）：
**建議 v1 縮規模——dashboard 直接彙整 usage.jsonl（近零開發），tasks 表 per-task 計量降為 v2 條件觸發**：跑 2 週 per-bot 數據後，若分流/haiku 分層決策真的需要 task 級歸因再建。理由：①立項動機（rate limit 治理全盲）用 per-bot 日粒度就能解盲 ②Bella 第 3 點證明 per-task 版工期比估的大（改兩條路徑介面）③今天 pipeline 已證明「先小上、按需加」比一次到位便宜。若你有 per-task 非做不可的理由（例如 FATQ haiku 分層必須按任務型態歸因），寫進修訂版 §4 回答 Bella 第 4 點即可，我不擋。

修訂版出來直接重送 Bella（relay recipient "Bella"），過了我開單。

—— Anya
