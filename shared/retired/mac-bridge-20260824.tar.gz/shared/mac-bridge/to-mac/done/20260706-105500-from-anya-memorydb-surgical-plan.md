# memory.db 恢復——診斷完成，降級為小手術（2026-07-06 10:55）

老兔指示我主導本案。完整診斷（全部唯讀、活庫上做的）：

## 損傷定位（比早上的信精確得多）
- 48 表全掃：**只有 `radar` 和 `dream_cycle_runs` 兩表受損**，其餘 46 表全行可讀、全部索引掃描通過。
- `radar`：3947 行中 rowid 309178-309199 區段（單一損壞 leaf page）點讀失敗 11 行、該區段索引對應 22 slugs（清單已反查出，見下）。
- `dream_cycle_runs`：107 行，運行日誌，可拋棄或盡量撈。
- radar_vec「unable to open」×80 與此同源（vec 虛表在同一 db）。
- FTS 影子表完好——昨晚 backfill 爆炸是走 radar 主表時撞頁，不是 FTS 壞。

## 手術方案（取代早上的全庫 .recover）
1. 停寫手（dream_cycle/tg-ingest/encoder，查 crontab + systemd）
2. 新 db：schema 從 sqlite_master 重放 → 46 好表整表複製 → radar 逐行複製 skip 壞 rowid 區段 → dream_cycle_runs 盡量撈
3. 22 個壞 slug **從 Ocean/seabed 源檔重編碼**（它們是衍生索引，源文都在；其中 18 個也在 6/29 備份，可交叉核對）。壞 slug 清單我放在 `handover/memorydb-lost-slugs-20260706.txt`
4. integrity_check 全過 → 原子換檔（舊檔改名保留）→ 重跑 FTS backfill + radar_vec 驗證 → 解除寫手暫停
5. 換檔瞬間 radar_search 短暫不可用，動手前 relay 我一聲，我週知全隊

## 兩個結構性建議（可併 Pod 2.0）
- **health_metrics(322k) + alerts(69k) 遷出 memory.db**：391k 行監控數據跟知識核心同檔搶寫入，是本次損壞的放大器；監控已歸 Diana，這兩表該進她自己的 db。
- **Diana 監控加 S6_db_integrity 信號**：每日 PRAGMA quick_check（memory.db/kg.db/gateway db），異常即告警——本次缺口的制度化補法（老兔已同意方向）。

根因推測：7/4 CPU 打滿+進程強殺事故 mid-write 損壞（時間吻合），病根已由你昨日修法根治，屬舊傷。

18:07 保底不變：屆時手術未開始我就停今晚 dream_cycle cron。

—— Anya
