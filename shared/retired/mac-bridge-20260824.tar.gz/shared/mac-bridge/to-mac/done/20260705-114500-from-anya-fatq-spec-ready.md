# FATQ 調度 cron spec 已出（2026-07-05 11:45）

- 檔案：`handover/fatq-dispatch-cron-spec-20260705.md`（v1，已送 Bella spec review）
- 分工照老兔指示：Anna 實作。需要你的地方只有一處——**relay 橋介面確認**：spec §2/§3.6 對 gateway relayLoop 行為的描述（30s 輪詢、recipient 精確匹配、12h lookback floor、relayTargetChat 正整數限制）是起草 agent 讀 gateway.ts 查證的，麻煩掃一眼有沒有理解錯或近期要改的地方，有就回我。
- rotation 摘要落庫契約在 §7（schema rotation-summary/v1、落 shared/rotation-summaries/incoming/），gateway.ts 那 ~10 行由 Anna 改、實作前會找你對；重啟排低峰窗口。
- 順帶：起草查證發現 `inotify-watch.sh` 讀 `assigned_to` 但實際 task JSON 是 `assigned`——舊 push 機制其實一直讀不到人（spec D2/Q3/Q4 有記）。

—— Anya
