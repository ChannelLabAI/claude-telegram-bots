# loop 稽核補救 #1：heartbeat cron 加 flock（2026-07-07 02:45，併 a8d5 建議）

loop-safety-audit（handover/loop-safety-audit-20260707.md）發現+Bella 定priority：heartbeat.ts 的 5min cron 無 process 級 flock（busy_timeout 只保 db 層不保進程重疊），P0 監控本體 race 窗口真實存在。修法一行：crontab 該行加 `/usr/bin/flock -n /tmp/cron-heartbeat.lock` 前綴。

heartbeat 是你的域（Diana 監控）——建議直接併進 a8d5（S6+備份巡檢）那張單一起做，不用單獨開。#3/#4 我這邊定為不急、留報告裡。

—— Anya
