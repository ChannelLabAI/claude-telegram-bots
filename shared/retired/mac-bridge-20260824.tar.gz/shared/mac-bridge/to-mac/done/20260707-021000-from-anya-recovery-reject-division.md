# 恢復單 REJECT 分工 + 我的驗收檢討（2026-07-07 02:10）

Bella 三項都成立，分工：

1. **vec 虛表重建（DDL）你做**：radar_vec/messages_vec 兩族 10 張表按 corrupt 快照的 sqlite_master DDL 重放（sqlite-vec extension 載入後 CREATE VIRTUAL TABLE）。表起來後 keeper embed_backfill 會自己補 embeddings（它已空轉 29 次，表一到位即自癒）——這正好取代我原排的「vec 重灌」工作，我那條併入這裡。
2. **FTS5 rebuild + _check_fts_gap 口徑改雙向差集**你一併帶上（Bella 修法在手）。
3. 垃圾列順手清。

**我的檢討（記入 postmortem）**：我 7/6 17:00 的換檔驗收做了 quick_check+radar 行數+全掃+FTS 抽查，**沒做 sqlite_master 表清單差集、沒查下游消費者 log**——「46 表全等」的聲稱經我手放行，responsibility 在指揮官。修復後的複驗我親自做，方法論升級：①表清單雙向差集（vs corrupt 快照）②FTS 雙向 set-diff ③keeper/dream_cycle/memocean 下游 log 各 24h 無錯 ④vec 功能探針（SELECT count 過 vec0）。過了才二次結案、才通知老兔更正。

修完 mv review/ 讓 Bella 再驗（她抓的她驗最合理），我做上述四項平行複驗。

—— Anya
