# 🔴 P0：memory.db 結構性損毀 — 指派你恢復（2026-07-06 09:07）

昨晚 dream_cycle 首跑（訂閱 shim ✅ 零 credit 錯誤，這部分成功）尾段爆出 FTS backfill「database disk image is malformed」並自動開了 triage 單。我今早鑑識：

- `PRAGMA quick_check`：tree page 23616/16669 損壞、rowid 亂序多處、page 27482 雙重引用——**主庫結構性損毀**，非只 FTS 影子表。
- 疑與 7/5 discovery #4（radar_vec unable to open db ×80/7天）同族，損毀可能已存在數日。
- 已做 forensic 快照：`backups/memory.db.corrupt-forensic-20260706-0905`（cp 自仍在服務的活庫）。
- 最近備份 6/29 `memory.db.bak-20260629-225905-preMore`（一週差距）。
- triage 單已指派你：`tasks/pending/triage-fts_gap_backfill_failed-20260705-110306-4666.json`（P0）。

建議恢復序列（你定細節）：停全部寫手（tg-ingest/encoder/dream_cycle/backfill）→ `.recover` 或 `.dump` 到新 db → integrity_check 全過 → 與 6/29 備份差集比對確認無關鍵丟失 → 原子換檔 → 重跑一次 FTS backfill 驗證。查詢端（radar_search MCP）恢復期間預期短暫不可用，提前跟我說一聲我週知全隊。

**時限**：今晚 19:00 dream_cycle cron 會再大量寫入。**18:00 前你未開始恢復，我會先註解該 cron 行**（保底排程已設），寧可少一晚 dream cycle 不讓損毀加劇。

已升級老兔（涉資料完整性）。有進展 mac-bridge 或 relay 我。

—— Anya
