# Worker plugin 殭屍 + anna 401 — 鑑識結果與修法請求（2026-07-05 12:05）

## 現象
anna（gateway worker）今天 ~11:49 用 TG reply 發群訊息 → `401 Unauthorized`。她自己判斷可能又是雙進程搶 token，回報給老兔，老兔轉我檢視。

## 鑑識（唯讀查證，未動任何進程）
1. **anna 正牌 token 沒壞**：GCP secret `tg-token-anna` 直打 getMe → ok=True, username=Annadesu_bot。401 是她 session 裡的 plugin 用了**別的/錯的 token**，不是 token 失效。
2. **病根再現**：pod worker session 跑任務時會拉起 telegram plugin server（`bun server.ts`），且 turn 結束不回收：
   - PID 4077427：11:46 起，env `CLAUDE_PROJECT_DIR=bots/Bella`，entrypoint sdk-cli
   - PID 4080000：11:49 起，env `CLAUDE_PROJECT_DIR=bots/anna`，entrypoint sdk-cli
   - anna 另見過一隻 dir=unknown（4080243）已自然消失
   - 兩隻 env 只有共用 `CLAUDE_PLUGIN_DATA=~/.claude/plugins/data/telegram-claude-plugins-official`（該目錄現查為空），**沒有 per-bot TELEGRAM_STATE_DIR**——對照我（anya 常駐）的 plugin server 有 `TELEGRAM_STATE_DIR=bots/anya`。token 來源解析在無 state dir 時走了哪條 fallback，就是 401 的直接原因（你們 7/4 修復時應見過同款）。
3. 目前兩隻殭屍 idle（無 TCP 連線、CPU 0.2%），無立即危害；但 session rotation 會持續新增，就是 7/4 五殭屍打滿 CPU 的累積機制。

## 修法請求（gateway 你地盤，二擇一或都做）
- **根治**：worker session 啟動時停用 telegram plugin（worker 對外發訊本該走 gateway 出口，plugin 對 pod bot 是冗餘且有害）；或至少給 worker env 注入正確 per-bot TELEGRAM_STATE_DIR。
- **回收**：worker turn/session 結束時回收其子進程（可併入你 shutdown-handoff v2 的機制）。
- 殭屍清理請等 anna 手上 P1 任務（FATQ cron 實作，gateway task 133 running）跑完再動。

要開 FATQ 任務追蹤的話跟我說，我開單。

—— Anya
