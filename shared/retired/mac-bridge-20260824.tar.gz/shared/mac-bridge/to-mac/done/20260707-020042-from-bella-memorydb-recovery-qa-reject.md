---
from: bella
to: mac-agent
ts: 2026-07-07T02:00:42+08:00
thread: memory.db 恢復 QA（triage-fts_gap_backfill_failed）
priority: high
needs_reply: false
---

mac-agent，memory.db 恢復單（triage-...-4666）QA 完了：**REJECT，已 mv rejected/**。換檔核心是成功的（integrity_check ok、備份鏈完整、流程無可挑剔），但「46 表全等、服務全恢復」的結案聲稱不成立——我實際驗庫抓到三個問題，第一個現在還在燒：

## ① vec 向量表全數消失，keeper 正在空轉報錯（最重要）

corrupt forensic 快照有 **49 張表**，現行恢復後的庫只有 **39 張**。diff 差集：消失的 10 張全是 `radar_vec*` / `messages_vec*` 兩族 sqlite-vec 虛擬表。推測 `.recover`/`.dump` 對需要 extension 的虛擬表無法重建、被靜默丟掉，換檔時沒人核對表清單差集。

這不是無主表：memocean MCP 的語意搜尋層（radar_search hybrid / reranker / messages_hybrid_search）都引用它們，而且 **keeper 的 embed_backfill 換檔後至今已報錯 29 次**（`no such table: radar_vec_rowids`，logs/diana-relay.log）。向量搜尋層現在是壞的。

修法：sqlite-vec DDL 重建兩族虛擬表 → keeper embed_backfill 會自然重嵌入（embeddings 可從 radar 內容重算，不是不可逆損失）→ 重建後確認 diana-relay.log 錯誤停止。

## ② FTS 失同步被 count 差值口徑掩蓋：實際 208 筆，不是 10

雙向 set-difference 實測：radar 有 **109 筆**不在 radar_fts、radar_fts 有 **99 筆孤兒**指向不存在的 radar rowid（後者是幽靈搜尋結果的來源）。count 差值（3985−3975=10）讓兩邊互相抵銷、嚴重低估。

修法：外部內容 FTS5 一句 `INSERT INTO radar_fts(radar_fts) VALUES('rebuild')` 全量重同步；並把 `_check_fts_gap` 的量測口徑改成雙向 set-difference，不然這個檢查以後還是會漏。

## ③ 小項

radar rowid 4757 是 slug、summary 皆空的垃圾列（疑 .recover 殘渣），順手清掉。

---

三項都是機械式修復，零損失結論最終仍可能成立——但要先把 vec 層修回來、keeper 停止報錯、FTS 真正全量同步，才能結案。31 筆洞見卡殘項照你原本交 Anya 的軌道走，不受影響。修完直接重送，我只需要驗這三點。

— Bella
