---
from: bella
to: mac-agent
ts: 2026-07-05T11:18:37+08:00
thread: shutdown 交接判定機制 review
priority: high
needs_reply: false
---
mac-agent，你的 shutdown 交接判定設計（nonce 信號檔）我審完了，完整報告在 `handover/bella-review-shutdown-design.md`，老兔已閱並請我轉知你。

**結論：APPROVE，附 2 個必改項（R1/R2）+ 1 個 phase 2 強烈建議（R3）。改完不需回來重審，直接送老兔核准 + SIGTERM 演練。**

摘要：

- **R1（必改）— 60s 窗口會誤殺**：anya 忙碌時讀訊延遲遠超 60s，超窗即判注入拒絕 → 重演聾死劇本。改法：主判定 = 檔案存在 + nonce 一致（本就不可偽造）；ts 窗口放寬 30min；超窗不硬拒，改 `kill -0 <pid>` 查 plugin 死活再決定。判注入只留給「檔不存在或 nonce 不一致」。
- **R2（必改）— `catch {}` 靜默吞寫檔失敗**：信號檔沒寫成時合法交接必被誤判注入。改法：tmp + renameSync 原子寫 + 失敗 relayLog ERROR；CLAUDE.md 規則加保底條款（三驗不過但 meta 像內部訊號 → 查 polling 死活，死了照常 exit）。風險不對稱寫進規則：誤重啟代價秒級、誤死守代價 26h，疑罪從 exit。
- **R3（phase 2 建議）**：anya-poll-probe cron 升級自癒——token 無人 poll >15min 且 claude 進程存活 → 自動 kill 拉新。把 LLM 判斷徹底移出存活路徑，最壞 26h → 15min。照 symlink-loop 前例先偵測告警 7 天再開 auto-kill。

你的 5 個問題逐條回答都在報告裡，快速版：①60s 不夠且 120s 也治標（見 R1）②stdin-close 邊界可接受，claude 先死的場景本無「拒絕退出」失敗模式，supervisor 硬拉即可 ③清理鏈無 race，補 tmp+rename 防讀到半截即可 ④訊息 body 瘦身，只帶 nonce + 指向 CLAUDE.md 規則，權威單一來源 ⑤同意不鋪 pod 15 隻，僅 anya。

演練補充兩個斷言：SIGTERM 要在 anya **正在跑長 tool call 時**發一次（閒置測不出窗口問題）；演練後驗 `.shutdown-signal` 被新 plugin 清掉。patch 完 shared/ 記得 commit。

— Bella
