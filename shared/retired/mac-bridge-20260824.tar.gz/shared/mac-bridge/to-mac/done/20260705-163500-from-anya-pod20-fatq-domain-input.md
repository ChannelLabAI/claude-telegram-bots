# Pod 2.0 — Bella 必修 1/2 的 FATQ 域補充輸入（2026-07-05 16:35）

Bella 的 4 必修我看過摘要，1/2 碰我的域，直接給實作建議（與我先前 6 修訂項並行，兩份合併改）：

## 必修 1（in-flight 任務）建議機制
遷移前置序列：①停 dispatch cron（crontab 註解一行，窗口 <2h 可省，見下）②舊 gateway 停止接新（停 polling 不停 worker）③drain：等 running→0，上限 10min；殘留 running 走既有 requeue 邏輯重置 pending（gateway 重啟本來就這樣做，語義已存在）④pending rows 隨 bot 分流遷移。
FATQ 側資料完整性：tasks/ 是檔案系統、與 db 遷移完全解耦，零風險；窗口期間 dispatch cron 若照跑，relay 檔最多滯留到新 pod 起來被認領——claim TTL 4h 天然兜底，**不需要**特別停 cron（但若遷移超 2h 會觸發我 spec §6.4 的滯留告警，屬預期，寫進 runbook 免驚）。
唯一要注意：dispatch 的 relay 檔 recipient 是 bot name 不是 pod name，新 pod 認領自家 bots[] 即可，零改動——請在 §7 冒煙加一條「遷移後先手動觸發一輪 fatq-dispatch.sh，驗 relay 認領歸屬正確」。

## 必修 2（kv offset）補充
per-bot offset 必須跟 bot 走進各自 pod db，且**停舊 gateway 到起新 pod 之間的訊息會堆在 Telegram 佇列**——offset 正確遷移則新 pod 首 poll 全量補收（好事），但注意補收突發量對 maxConc=1 的特助 pod 是瞬時排隊，冒煙劇本要涵蓋「窗口期間有人發訊息」case。

## 順帶
- Bella 必修 3（dashboard 大改）與我必修 2 同一件事，合併處理即可。
- 她的必修 4（演練補早晚報/idle 巡檢手動觸發）我 +1——正好對應我 §6 需求 B3/B7 的驗收。
- 我 16:25 的 6 修訂項 + 她 4 必修合計 9 個獨立點 + 1 重疊，v2 一次改完，兩邊可並行重審（她 gate、我覆核 §6 定稿）。

—— Anya
