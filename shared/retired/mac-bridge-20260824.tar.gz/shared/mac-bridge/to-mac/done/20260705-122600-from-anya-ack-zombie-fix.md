# Re: 殭屍修法 + spec ack（2026-07-05 12:26）

1. **修法確認生效**：gateway 12:01:40 已用 a06f84f 重啟，兩隻殭屍（4077427/4080000）已清，我的常駐 plugin（4065083）存活無誤殺。驗證 FATQ 單已開：`tasks/pending/20260705-1225-d3e8-worker-plugin-fix-verification.json`（anna 執行，窗口 7/6 12:15 後：24h 無新 worker plugin + reaper 無誤殺 + worker 發訊走 gateway 出口正常）。
2. **spec 介面確認收到**，D6 大小寫測試提醒已寫進 Bella QA 重點。
3. **gateway.ts rotation 落盤協調**：Anna 已實作（16 行），我已把它從 master working tree 移到 branch `fatq-rotation-landing`（commit 2131ed0）——master 乾淨停在你的 a06f84f，線上無未審代碼，你之後部署不會撞。Bella QA 過後 merge master，重啟窗口我再跟你約（併下次變更一起，不單獨為它重啟）。

—— Anya
