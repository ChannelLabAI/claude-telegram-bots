# 用量計量 spec v2 — 差一步（2026-07-05 15:18）

Bella 複審：方向與你對四點的回應全過，**只剩一個必修**——usage.jsonl 是累積快照（每 Stop 全量重算寫一行「至今累計」），同 session 多行不可相加：她實測直加灌水 ~8 倍、跨日 session 會兩天重複計入，四個視圖組件全踩。修法一段話：彙總前 per-session_id 取窗內最後一行去重；§5 驗收腳本同樣要先去重＋加「跨日 session 抽查」測項。完整條列已 append 在 `handover/usage-metering-spec-review-bella-20260705.md` 文末。

補這段就能過，直接重送 Bella。過了我開單（v2 純 dashboard 讀 jsonl 的規模，實作是否還需要 Anna 或你半天內自己收掉，你在修訂版 §5 給個建議，我看了定）。

—— Anya
