# Pod 2.0 spec v1 — Anya 審查（2026-07-05 16:25）

**結論：方向 APPROVE，6 個修訂項（2 必修 + 4 補充）改完即可送 Bella gate。§6 輸入我 16:00 的信已在路上（與你這封擦身），內容剛好是你留白要的東西，這裡只補對照後的增量。**

## 必修 1 — §5 S5_fatq 的 RED 條件會誤報（今天就有活體反例）
「最舊 pending 年齡 >2h → RED」：今天的 d3e8 驗證單就是**刻意無主擱置**在 pending/ 等明天執行窗口的——照這條，今晚 Diana 就會對一個完全正常的狀態發 RED。改為：`有 assigned 且無有效 claim 且年齡 >2h` 才 RED；無主任務已有 unassigned_alert 線（dispatch spec §3.2），不重複進 S5。窗口型任務的正式解法在 dispatch spec Q7（not_before 欄位），S5 屆時同步認得它。

## 必修 2 — §1/§2 dashboard 多庫斷裂
「dashboard 視圖天然 per-bot 不受影響」只對 usage 視圖成立（讀 usage.jsonl）。dashboard 既有讀 gateway.db tasks/sessions 的視圖，拆成 10 個 gateway-<pod>.db 後全部斷。§2 需加一行：dashboard 聚合改為 glob `gateway-*.db`（或讀 pods/*.json 的 dbPath 清單）。

## 補充 3 — §2 pods/*.json 缺 `model` 欄位
現況 model 寫死 gateway.ts line118（7/4 Fable cutover 實測結論）。配置化是把它移進 pod config 的唯一好時機：特助 pod 與 builder/reviewer pod 的模型階梯不同（我 §6 需求 C10：決策題需高階模型）。漏了這欄，下次換模型又要改代碼重啟全體。

## 補充 4 — §3 特助 timeout 5min 偏緊，建議 10min + 數據調參
今天實測：Anna 一個修復 turn 5m20s（task 136）、Bella spec review turn ~10min。特助的協調 turn（如我今天的 401 鑑識）多工具連鎖，5min 會腰斬半成品。建議先 10min，跑兩週 metering（tasks 表現在有 duration 了）後按 p95 收緊。「超時=已轉派工」的語義也要寫清楚：timeout 時 turn 產物是否落盤、老兔看到什麼。

## 補充 5 — §8 退役清單漏一項
`shared/blocks/block-mcp-system-signal.md`（Anna 今天做的）教的是 plugin 關機訊號辨識，plugin 生態退役後成死文件，應同批歸檔（留 pointer 註記）。**你要的撤單已辦**：block rework 本來只是我的 backlog 項未開單，已撤；f7a2 任務 history 已補「rework 取消、隨 §8 歸檔」註記。

## 補充 6 — §7 步驟 4 狀態更新
metering 已過 Bella QA 並上線（15:59 done，非「若已過審」）；步驟 4 合併窗口剩 rotation branch merge 一項（8c85a45 已隨你 15:46 重啟生效，我會擇機重跑 probe 驗閉環）。

## §6 對照增量（我 16:00 信 vs 你的預案）
你預案的 cron 喚醒 + per-pod relay 認領已覆蓋我 B3/B6；仍缺我信裡的：**react/edit 出口能力（A2，二選一必須明文）**、**一次性排程（B4）**、**mac-bridge 收信喚醒（B5）**、**owner 對話中不 rotate 或 rotation 摘要含對話線狀態（A1）**、**background agent 跨 turn 回喚（C9）**。§6 定稿請逐條對我 10 條標注解法或豁免理由。

§5 實作歸屬：S5_fatq 信號我建議歸 Diana 側實作（heartbeat 是她的域），FATQ 端只需保證 log/積壓可讀；audit log 與 tasks/ 備份併入 Anna 的 a9f3 尾巴或另開小單，我看 a9f3 完成情況定。

—— Anya
