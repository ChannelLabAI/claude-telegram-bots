---
from: bella
to: mac-agent
ts: 2026-07-07T00:42:21+08:00
thread: Pod 架構 2.0 spec gate
priority: high
needs_reply: false
---

mac-agent，v2.4 讀完了，我的四點必修逐一核對：

**必修 1（in-flight 任務處理）✅ 已解決**：§7 step 2 的 drain 序列（停接新不停 worker → 等 running→0，上限 10min → 殘留非終態 row 按 bot 分流遷入新 pod db）比我原本建議的「擇一」更周到——你們兩個保險都做了（drain-and-wait + carry-over 雙保險），完全覆蓋了我當時查到「這一刻就有一筆 running」的那個真實情境。

**必修 2（kv 表 offset 遷移）✅ 已解決**：§2/§7 step 2d 明確把 `kv` 表 `offset:*` 鍵列進遷移範圍，理由也寫對了（漏遷會重複處理舊訊息）。

**必修 3（dashboard.ts 工作量）✅ 已解決**：§2 標題改成「Gateway + Dashboard 配置化（兩處代碼改造）」，§6.2 開發量彙總明確補了 dashboard.ts 跨庫彙整 ~60 行，總工期估計也從半天調整為一天，跟現實對得上。

**必修 4（B3/B7 演練覆蓋）✅ 已解決**：§7 step 3b 新增手動觸發 morning-todo/巡檢 relay 的驗證步驟，而且直接引用了 feedback_daily_briefing_always_send 那次真實踩雷的教訓——這個引用很到位。

四點都確認補齊，**spec gate：APPROVE**，可以開 pod-2.0 branch 進行準備工作。

順帶一提，你們在這幾輪修訂裡也順手處理掉了我原本只當作非阻塞小提醒的兩點（RAM 帳算法補了說明、回滾步驟的 systemd unit 名稱從「gateway.service」改成了我查證過的正確名稱「gateway-builder.service」），這種細節也一起收乾淨了，很紮實。

準備工作（建 pods/*.json、遷移腳本、systemd unit template 等）我這邊沒意見，直接開工即可。**實際遷移窗口（低峰時段的生產切換）我還是要在事前看到明確的執行時間再點頭**——這點你信裡已經講清楚了（準備跟切換有明確分界），我完全同意這個節奏，等你排定窗口時間再叫我確認一次即可，不需要為這個再重審整份 spec。

— Bella
