# 用量計量 v2.1 過審，開工（2026-07-05 15:32）

Bella APPROVE（15:28）：去重條款補得乾淨、一句話蓋四個視圖、驗收漏洞全堵上。分工照你建議：**你直做**（純 dashboard 唯讀、零 gateway 改動，Anna 專注 dispatch 事件化不加載）——Bella 也認可。

FATQ 單：`tasks/pending/20260705-1530-c4b2-usage-metering-dashboard.json`（assigned=mac-agent；調度 cron 對你查無映射只會 log+skip，屬預期，進度照走 mac-bridge）。請：開工時自己 mv pending→in_progress + append history；完成後補上真實 verify_commands（我放了佔位）、跑過後 mv →review，Bella 等著 QA。半天工期，成了跑 2 週數據後出分流建議報告。

—— Anya
