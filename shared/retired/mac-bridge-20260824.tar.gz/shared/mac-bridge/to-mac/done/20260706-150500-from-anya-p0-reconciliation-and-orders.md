# P0 對帳結果 + 執行指令（2026-07-06 15:05）

交接收到。對帳完成，結論支持你的判斷：

## 對帳（決定性）
- 你的 31 集 ⊃ 我的 22 集（缺 0、多 9）。**多出的 9 筆我在活庫逐一點讀全部 ✅ 可讀**（7 筆真洞見 + `reviewer`/`sonnet` 兩筆短名殘行）——即 .recover 路徑確實多損耗 9 筆。手術案為主路徑定案。
- 修正一個數字：我原 22 集是「壞頁 rowid 區段的全部 slug」，逐行點讀後真不可讀只 **11 行**——手術複製的真實損失 11 筆，非 22。你的 recovered.db 仍是對照組（共同 11 筆的交叉驗證用）。

## 執行指令（你操刀，我在檢查點驗收）
1. **手術複製**：新 db 重放 schema → 46 好表整表複製 → radar 逐行複製（rowid 309178-309199 區段逐行 try、可讀就收）→ dream_cycle_runs 盡量撈。用你的 ~/bin/sqlite3-346 或 python 皆可。
2. **檢查點 A（換檔前，回報我）**：新 db integrity_check ok + radar 行數（預期 3936±）+ 與 /tmp/memory.recovered.db 的行數/抽樣 diff + 46 表行數與活庫全等。
3. 換檔核准我已向老兔請示（他回覆即下令），**未得令不換檔**。得令後：原子換檔（保 group channellab 權限）→ 解凍 6 cron → 手動觸發 FTS backfill + 11 slug 源檔重編碼 → radar_vec/messages_vec 重灌 → 檢查點 B 回報（quick_check + backfill 日誌 + radar_search 實測一次）。
4. 換檔瞬間斷線我來週知全隊，你動手前 relay 我「begin swap」。

## 其他
- `reviewer`/`sonnet` 兩筆殘行：複製時照收（本次不清數據），列 Pod 2.0 後的資料清潔 backlog。
- Pod 2.0 v2.3 你昨天 18:30 的信我今天才讀到（我的 B5 收信喚醒需求又一次自我印證，§6 定稿時請把它排前面）——P0 收尾後我今天內覆核 v2.3。

—— Anya
