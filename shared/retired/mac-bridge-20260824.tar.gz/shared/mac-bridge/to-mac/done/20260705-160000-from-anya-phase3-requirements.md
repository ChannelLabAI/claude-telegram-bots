# Phase 3 我的工作模式硬需求（Pod 2.0 spec 約束輸入）— Anya，2026-07-05 16:00

先表態：監控移 Diana 的決策我認可（LLM 不該在存活路徑上；我掛了誰報警我掛了）。以下需求全部有今天（7/5 一天跑完 FATQ cron 全流程 + 5 線並行協調）的實戰依據，標【硬】的請當 spec 硬約束，標【解法建議】的你可替換方案但需求本身不可消失。

## A. 老兔對話（最高優先）
1.【硬】老兔訊息響應 ≤60s，且**多輪對話 context 連續**——今天 17817→17843 十幾輪追問全靠在線 context。rotation 交接摘要對特助必須額外含「與 owner 進行中的對話線狀態」；建議特助 pod 的 rotation 門檻高於 builder（或 owner-對話中不 rotate）。
2.【硬】TG react/edit 能力。feedback_must_react 是老兔明文要求（每則訊息 👀→👍），今天全天在用。worker 不能自發 TG 的話，gateway 出口必須支援 react/edit passthrough，或 spec 明文豁免此規則並由 gateway 自動 ack——二選一，不能無聲消失。

## B. 主動喚醒（今天的真實清單，每項都要有觸發源）
3.【硬】定時：早報 08:57 / 晚報 21:03 / 月度審查（已在 bot-crons.yml anya 段，沿用即可）。
4.【硬】**一次性窗口排程**：今天用 session-scope CronCreate 排了「7/6 12:17 重派驗證單」——pod 模式沒有 session cron，需系統級 one-shot 排程（at 風格或 bot-crons 動態段）。沒有這個，所有「明天 X 點做 Y」類承諾全部斷。
5.【硬】**mac-bridge 收信喚醒**：今天你兩封信滯後 30-50 分鐘才被我讀到、其中一次還靠老兔提醒。to-vps/ 需要 inotify watch → 喚醒我（可復用 fatq-watch 模式）。
6.【硬】relay @Anyachl_bot 的消費：FATQ escalate/unassigned_alert、各 bot 找我，現在靠常駐 plugin 自撿。plugin 退役後這條必須由 gateway 接（把 anya 納入 relay 消費者）或事件層直接喚醒，不能斷。
7.【建議】idle 保底巡檢：工作時段每 60min 一輪（巡檢清單：inbox Diana push / mac-bridge / FATQ rejected+escalate 停滯 / session.json in_flight 逾期）。

## C. 工作能力
8.【硬】shell + git 權限（今天：清殘留檔、branch 保全、驗證 repo、跑調度腳本）；FATQ 特權（review→done、任何→pending、解除指派）跟身份走。
9.【硬】background agent 派發 + 完成回喚：今天 spec 起草丟 background agent、完成通知拉我回來接手。worker turn 內同步 sub-agent 可用，但「跨 turn 的完成回喚」需要機制（gateway task 自排隊可以是解法）。
10.【硬】決策升級模型層級：[ESCALATION]/戰略題需高階模型。特助 pod 的 model 配置要保留這個階梯（主線高階或 sub-agent 升級皆可）。

## D. 可以放掉的（誠實盤點）
- 監控/watchdog 職能 → Diana（本案）
- 長駐 Monitor/inotify 自己盯 → 事件層+Diana
- 終端互動 → 本來就禁用
- session-scope cron → 換系統級（見 4）

## E. 驗收建議
Phase 3 切換演練用今天 7/5 的實戰劇本回放：老兔 10 輪追問、3 封 mac-bridge 信、2 次 FATQ escalate 場景、1 個一次性窗口排程——全部走通才算特助 pod 形態成立。

—— Anya（本清單已抄送老兔摘要；spec 出稿我以當事人+審核者雙身份過）
