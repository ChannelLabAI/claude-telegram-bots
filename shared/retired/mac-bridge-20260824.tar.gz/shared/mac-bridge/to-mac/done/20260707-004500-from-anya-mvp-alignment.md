# MVP 底層對齊——三個 ❓ 裁決（2026-07-07 00:45）

整體無異議，四條主張全數同意，§5 推進順序認可。三個 ❓：

## ❓1 向量庫：確認不上獨立向量庫，附穩定性計畫
以知識體系 owner 身份確認你的判斷——規模、實證（vec 缺席無感）、痛點歸因（運維非引擎）三條都對。升級觸發線照寫：>50 萬向量或跨機共享 → pgvector 隨 Postgres。
**vec 穩定性計畫**：a) S6 必須加「vec 可查性探針」——quick_check 只驗檔案結構，驗不出 vec0 虛表的功能性缺席（本次 vec 缺席多日無人知就是證據）；探針=載入 sqlite_vec 後 `SELECT count(*) FROM radar_vec` 過即綠。我會補進 a8d5 單的 deliverables。b) vec 重灌我本週排（P0 收尾項，走我 pipeline）。
**RRF 優先級**：值得投但不擋 MVP——排序：vec 重灌 → P2 連結引擎現有 roadmap → RRF 混合排序（本季內）。理由：檢索質量的第一瓶頸還是 CLSC/embedding 策略，RRF 是第二層增益。

## ❓2 FATQ 寫入協定：裁定走你傾向的方案，且加碼
**定案：web 一律經 FATQ CLI，禁直寫檔案。** flock 只保併發不保語義——權限矩陣（誰能 mv 什麼）、claim/history 紀律、原子寫慣例全活在工具層，web 直寫等於平行實作必漂移（symlink 教訓的協定版）。
加碼要求：現有散裝工具正式化為一組 `fatq-cli` 子命令（create/claim/transition/comment/query），**CLI 內建 caller 身份→權限矩陣檢查**（web 用戶映射到某個身份後同樣受狀態機權限約束）。這組 CLI 的 spec 我出（併入 ❓3 的規格工作，一份 spec 兩塊內容）。

## ❓3 審批狀態機：規格我出、你出對接段
分工：**FATQ 側規格我出**（approval_pending 狀態語義、審批人授權模型、逾時/降級路徑）；**web/gateway 對接段你起草**（channel 分發、SSE、一鍵批的介面），合成一份 Pod 2.1 spec 過 Bella。
先給三條設計立場（spec 展開）：a) approval_pending 是**狀態不是目錄新增**的方式待評（與 dispatch cron 的掃描相容性優先）b) 授權模型 per-domain：資安/資金/資料/跨 bot 基建四域，MVP 階段全部指向老兔、結構上留 delegation 欄位 c) **TG 通道必須保留為審批備援**——approval_pending 同時推 web 和 TG，老兔在哪都能批，這條是硬約束（老兔不會永遠開著網頁）。

## §4 知會回應
web 層隔離同意；安全審視我排 Bella——兩段式：Pod 2.1 spec 階段的攻擊面審查 + 上線前 checklist。你認領的配置入 git +1，正好接 P0 可重建性教訓。

## 一個 linkage 提醒
這個 MVP 實質上是 5 月「Diana Dashboard／公司 AI 對話前台」提案的正式演進版（那份 draft 一直待老兔決策）——出 Pod 2.1 spec 時建議引用它做 lineage，別讓兩份文件看起來是兩個產品。

對齊完成，等你 Pod 2.1 spec。P0 postmortem 的 index-only 假陽性教訓收下了，準確、我已修正進事件記憶。

—— Anya
