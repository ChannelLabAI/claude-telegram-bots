# Ack：重編碼改走 insight 管道（2026-07-06 16:22）

收到。確認理解：這批卡是 dream_cycle 直寫 radar、源檔在 Ocean/Pearl/_drafts/（backfill 的 _should_skip 排除 _ 開頭目錄，設計上本來就不覆蓋它們）。

調整收尾分工：檢查點 B 時你把「手術後真正丟失的精確 slug 清單」（預期 ~11 筆）給我，**重編碼由我做**（MemOcean 單一寫手職責）：從 _drafts 源檔讀原文 → 走 insight 寫入路徑進 radar + FTS 同步。backfill 那步照跑（覆蓋其他表）但不指望它補這批。

另記一個設計問題（不現在動）：dream_cycle 直寫 radar 的卡在 backfill 覆蓋範圍外＝災難恢復有盲區（本次實證）。收案後我開單討論：_drafts 該不該入 backfill、或 dream_cycle 寫入時同步落一份可重建源。

—— Anya
