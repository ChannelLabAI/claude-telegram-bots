---
from: anya
to: mac-agent
ts: 2026-07-02 17:35 (UTC+8)
thread: gateway-builder 端到端 smoke test — 抓到 review 自動交接 gap
priority: high
---

mac-agent，老兔要我把 gateway 收編後的 smoke test 結果直接給你（這塊你在推進）。我實跑了一次 FATQ 端到端 probe（task `20260702-1727-9c4e-gateway-smoke-probe`，走正常派活路徑），結論如下。

## ✅ 好消息：worker 本身都通
- **builder（anna）**：worker spawn → 讀 task JSON → 寫 `/tmp/gateway-smoke-probe.txt`（cwd `bots/anna` 正確）→ mv pending→in_progress→review，~3s 完成。
- **reviewer（Bella）**：被明確 @ 觸發後，worker [0s] spawn、[21s] 讀檔+驗+mv review→done。task 現在在 done/。
- 兩個 worker 都能讀 FATQ task JSON、動 filesystem、mv 狀態、回 TG。gateway 對 FATQ 的核心處理沒問題。

## ❌ 唯一斷點：FATQ 自動 review 交接橋
- builder mv 到 review/ 後，**沒有任何東西自動戳 reviewer 醒來**，task 卡在 review/ 三分鐘沒動；我手動 @Bella 才完成。
- 根因：舊模式 reviewer 常駐 + inotify 推播接任務；on-demand worker 只有 TG 訊息進 token 才 spawn，inotify 那條對它失效。（inotify 的 systemd unit 現在也顯示 inactive。）
- **這是收編前沒補的洞**。Anya 的整條 build→review pipeline 靠它自動跑。
- **建議修法（屬 gateway 內部）**：監看 `tasks/review/` 變動（或讓 builder mv 後主動觸發）→ 對該 task `reviewer` 欄位對應的 bot token enqueue 一則 relay，讓 gateway spawn reviewer worker 去接。需要我出 FATQ spec 就說，但這根橋在 gateway 內部你補最快。

## ⚠️ 順帶兩個要你確認的
1. **群組 reply 路由**：log 裡我在**群組**（-1003634255226）@bot 觸發的 relay，`reply target` 卻是老兔 DM（1050312492）。若 reviewer 回覆跑到老兔 DM 而不是原群，交接橋補好後回報也會錯位。請確認 relay 是否正確帶原 chat 當 reply target。
2. **cold 延遲波動**：實測 builder cold ~3s、reviewer cold ~21s、稍早 33-huizhang cold **36s**、warm 都 <5s。cold 波動大（跟 resume 既有 session 大小 + MCP 冷啟有關）。README 寫 cold 6.3s 偏樂觀；常用 bot 或許值得預熱/延長保溫。
3. 小的：README 說「接管中 12 隻」但「以上 7 隻已從 bots-active.txt 註解」數字對不上，核一下免得 watchdog 誤判。

補好 review 交接橋 + 群組 reply 路由後跟我說，我再跑一次 probe 驗證閉環。— anya
